-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 19, 2015 at 09:11 PM
-- Server version: 5.5.45-cll-lve
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `orderings`
--

-- --------------------------------------------------------

--
-- Table structure for table `cost_centers`
--

CREATE TABLE IF NOT EXISTS `cost_centers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `date_added` datetime NOT NULL,
  `added_by_user_id` int(11) NOT NULL,
  `added_by_username` varchar(100) NOT NULL,
  `last_updated_date` datetime NOT NULL,
  `last_updated_by_user_id` int(11) NOT NULL,
  `last_updated_by_username` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `cost_centers`
--

INSERT INTO `cost_centers` (`id`, `name`, `date_added`, `added_by_user_id`, `added_by_username`, `last_updated_date`, `last_updated_by_user_id`, `last_updated_by_username`) VALUES
(1, '1234ZYZ', '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, ''),
(2, '9876ABCD', '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(300) NOT NULL,
  `quantity` int(100) NOT NULL,
  `uom` varchar(100) NOT NULL,
  `vendor` varchar(100) NOT NULL,
  `vendor_name` varchar(200) NOT NULL,
  `catalog_no` varchar(200) NOT NULL,
  `price` float NOT NULL,
  `weblink` text NOT NULL,
  `cost_center` varchar(300) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `project_no` varchar(100) NOT NULL,
  `account_no` varchar(100) NOT NULL,
  `comments` varchar(1000) NOT NULL,
  `vendor_order_no` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `requested_by_id` int(100) NOT NULL,
  `requested_by_username` varchar(100) NOT NULL,
  `requested_datetime` datetime NOT NULL,
  `item_needed_by_date` date NOT NULL,
  `last_updated_by_id` int(100) NOT NULL,
  `last_updated_by_username` varchar(100) NOT NULL,
  `last_updated_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` varchar(100) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=100073 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `description`, `quantity`, `uom`, `vendor`, `vendor_name`, `catalog_no`, `price`, `weblink`, `cost_center`, `project_name`, `project_no`, `account_no`, `comments`, `vendor_order_no`, `invoice_no`, `requested_by_id`, `requested_by_username`, `requested_datetime`, `item_needed_by_date`, `last_updated_by_id`, `last_updated_by_username`, `last_updated_datetime`, `status`, `deleted`) VALUES
(100000, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, '', 'BioA', '', '', '987654321', 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', '', '', 1, 'engin.yapici', '2015-10-15 13:26:50', '0000-00-00', 9, 'john.doe', '2015-10-16 10:27:32', 'Backordered', 0),
(100001, 'Kimtech Sterile Sleeves', 1, '200/CS', '2', 'Sigma-Aldrich', '17-150-200', 218.03, '', 'BioA', '', '', '987654321\r\n', 'None', '', '', 1, 'engin.yapici', '2015-10-15 13:31:19', '0000-00-00', 9, 'john.doe', '2015-10-19 14:33:35', 'Received', 0),
(100002, '1000 uL Filter Tips, Sterile', 2, '960/PK', '2', 'Sigma-Aldrich', '02-707-404PM', 306.22, '', 'BioA', '', '', '987654321\r\n', 'None', '', '', 1, 'engin.yapici', '2015-10-15 13:44:46', '0000-00-00', 9, 'john.doe', '2015-10-22 11:32:36', 'Received', 0),
(100003, 'test', 0, 'test', '2', 'Sigma-Aldrich', 'test', 50, '', '1234567890', '', '', 'test', '', '', '', 1, 'engin.yapici', '2015-10-26 12:49:49', '0000-00-00', 1, '', '2015-10-26 12:49:49', 'Pending', 0),
(100004, 'tesst', 0, 'test', '2', 'Sigma-Aldrich', 'dsgsdfgh', 60, '', '1234567890', '', '', 'dfgh', '', '', '', 1, 'engin.yapici', '2015-10-26 12:53:09', '0000-00-00', 1, '', '2015-10-26 12:53:09', 'Pending', 0),
(100005, 'Nalgene Rapid-Flow Sterile Disposable Filter Units', 1, 'Case of 12', '2', 'Sigma-Aldrich', '09-740-28C', 217.9, '', '1234ZYZ', '', '', '', '', '', '', 1, 'engin.yapici', '2015-11-23 14:16:11', '0000-00-00', 1, '', '2015-11-23 14:16:11', 'Pending', 0),
(100006, 'Test1', 13, 'Case of 13', '2', 'Sigma-Aldrich', '12345678', 25, '', '9876ABCD', 'Project 2', '9876ABCD', 'XYZ12345ABCD', 'The standard chundfdfdk odfdsgfsgfsf Lodfdfdfdfdrem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 9, 'john.doe', '2015-12-14 10:13:42', 'Pending', 0),
(100007, 'Test2', 1, 'Case of 14', '2', 'Sigma-Aldrich', '12345679', 26, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100008, 'Test3', 1, 'Case of 15', '2', 'Sigma-Aldrich', '12345680', 27, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100009, 'Test4', 1, 'Case of 16', '2', 'Sigma-Aldrich', '12345681', 28, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100010, 'Test5', 1, 'Case of 17', '2', 'Sigma-Aldrich', '12345682', 29, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100011, 'Test6', 1, 'Case of 18', '2', 'Sigma-Aldrich', '12345683', 30, '', '1234ZYZ', 'Project 2', '9876ABCD', 'XYZ12345ABCD', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 9, 'john.doe', '2015-12-14 09:15:33', 'Pending', 0),
(100012, 'Test7', 1, 'Case of 19', '2', 'Sigma-Aldrich', '12345684', 31, '', '1234ZYZ', 'Project 2', '9876ABCD', 'ABCD12345XYZ', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 9, 'john.doe', '2015-12-14 09:17:40', 'Pending', 0),
(100013, 'Test8', 1, 'Case of 20', '2', 'Sigma-Aldrich', '12345685', 32, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-01-15 14:16:00', '0000-00-00', 1, '', '2012-01-15 14:16:00', 'Pending', 0),
(100014, 'Test9', 1, 'Case of 21', '2', 'Sigma-Aldrich', '12345686', 33, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-02-15 14:16:00', '0000-00-00', 1, '', '2012-02-15 14:16:00', 'Pending', 0),
(100015, 'Test10', 1, 'Case of 22', '2', 'Sigma-Aldrich', '12345687', 34, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-03-15 14:16:00', '0000-00-00', 1, '', '2012-03-15 14:16:00', 'Pending', 0),
(100016, 'Test11', 1, 'Case of 23', '2', 'Sigma-Aldrich', '12345688', 35, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-04-15 14:16:00', '0000-00-00', 1, '', '2012-04-15 14:16:00', 'Pending', 0),
(100017, 'Test12', 1, 'Case of 24', '2', 'Sigma-Aldrich', '12345689', 36, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-05-15 14:16:00', '0000-00-00', 1, '', '2012-05-15 14:16:00', 'Pending', 0),
(100018, 'Test13', 1, 'Case of 25', '2', 'Sigma-Aldrich', '12345690', 37, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-06-15 14:16:00', '0000-00-00', 1, '', '2012-06-15 14:16:00', 'Pending', 0),
(100019, 'Test14', 1, 'Case of 26', '2', 'Sigma-Aldrich', '12345691', 38, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-07-15 14:16:00', '0000-00-00', 1, '', '2012-07-15 14:16:00', 'Pending', 0),
(100020, 'Test15', 1, 'Case of 27', '2', 'Sigma-Aldrich', '12345692', 39, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-08-15 14:16:00', '0000-00-00', 1, '', '2012-08-15 14:16:00', 'Pending', 0),
(100021, 'Test16', 1, 'Case of 28', '2', 'Sigma-Aldrich', '12345693', 40, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-09-15 14:16:00', '0000-00-00', 1, '', '2012-09-15 14:16:00', 'Pending', 0),
(100022, 'Test17', 1, 'Case of 29', '2', 'Sigma-Aldrich', '12345694', 41, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-10-15 14:16:00', '0000-00-00', 1, '', '2012-10-15 14:16:00', 'Pending', 0),
(100023, 'Test18', 1, 'Case of 30', '1', 'Fisher Scientific', '12345695', 42, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-11-15 14:16:00', '0000-00-00', 1, '', '2012-11-15 14:16:00', 'Pending', 0),
(100024, 'Test19', 1, 'Case of 31', '1', 'Fisher Scientific', '12345696', 43, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2012-12-15 14:16:00', '0000-00-00', 1, '', '2012-12-15 14:16:00', 'Pending', 0),
(100025, 'Test20', 1, 'Case of 32', '1', 'Fisher Scientific', '12345697', 44, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100026, 'Test21', 1, 'Case of 33', '1', 'Fisher Scientific', '12345698', 45, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100027, 'Test22', 1, 'Case of 34', '1', 'Fisher Scientific', '12345699', 46, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100028, 'Test23', 1, 'Case of 35', '1', 'Fisher Scientific', '12345700', 47, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100029, 'Test24', 1, 'Case of 36', '1', 'Fisher Scientific', '12345701', 48, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100030, 'Test25', 1, 'Case of 37', '1', 'Fisher Scientific', '12345702', 49, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100031, 'Test26', 1, 'Case of 38', '1', 'Fisher Scientific', '12345703', 50, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100032, 'Test27', 1, 'Case of 39', '1', 'Fisher Scientific', '12345704', 51, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100033, 'Test28', 1, 'Case of 40', '1', 'Fisher Scientific', '12345705', 52, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100034, 'Test29', 1, 'Case of 41', '1', 'Fisher Scientific', '12345706', 53, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100035, 'Test30', 1, 'Case of 42', '1', 'Fisher Scientific', '12345707', 54, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100036, 'Test31', 1, 'Case of 43', '1', 'Fisher Scientific', '12345708', 55, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100037, 'Test32', 1, 'Case of 44', '1', 'Fisher Scientific', '12345709', 56, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100038, 'Test33', 1, 'Case of 45', '1', 'Fisher Scientific', '12345710', 57, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100039, 'Test34', 1, 'Case of 46', '1', 'Fisher Scientific', '12345711', 58, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100040, 'Test35', 1, 'Case of 47', '1', 'Fisher Scientific', '12345712', 59, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100041, 'Test36', 1, 'Case of 48', '1', 'Fisher Scientific', '12345713', 60, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100042, 'Test37', 1, 'Case of 49', '1', 'Fisher Scientific', '12345714', 61, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100043, 'Test38', 1, 'Case of 50', '1', 'Fisher Scientific', '12345715', 62, '', '1234ZYZ', '', '', '987654321\r\r', 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', 0),
(100044, 'Item 4578', 5, '12/Box', '1', 'Fisher Scientific', '098765432', 567, '', '9876ABCD', 'Project 2', '9876ABCD', 'XYZ12345ABCD', 'Testing', '', '', 1, 'engin.yapici', '2015-12-12 23:02:50', '0000-00-00', 9, 'john.doe', '2015-12-13 23:34:22', 'Pending', 0),
(100045, 'testing', 1, '12', '1', 'Fisher Scientific', '12345', 0, '', '1234ZYZ', '', '', '', '', '', '', 1, 'engin.yapici', '2015-12-12 23:04:13', '0000-00-00', 1, 'engin.yapici', '2015-12-12 23:04:13', 'Pending', 0),
(100046, 'test', 1, '12', '1', 'Fisher Scientific', '1234', 75, '', '1234ZYZ', '', '', 'test', '', '', '', 1, 'engin.yapici', '2015-12-12 23:10:24', '0000-00-00', 1, 'engin.yapici', '2015-12-12 23:10:24', 'Pending', 0),
(100047, 'test', 0, 'test', '1', 'Fisher Scientific', 'test', 54, '', '1234ZYZ', 'Project 1', '9876ABCD', 'XYZ12345ABCD', '', '', '', 1, 'engin.yapici', '2015-12-12 23:16:41', '0000-00-00', 9, 'john.doe', '2015-12-14 10:11:48', 'Pending', 0),
(100048, 'test', 1, 'test', '1', 'Fisher Scientific', 'test', 2345, '', '1234ZYZ', '', '', 'test', 'testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttest', '', '', 1, 'engin.yapici', '2015-12-12 23:22:45', '0000-00-00', 1, 'engin.yapici', '2015-12-12 23:22:45', 'Pending', 0),
(100049, 'test', 5, 'test', '1', 'Fisher Scientific', 'test', 4, '', '9876ABCD', '', '', 'test', 'test', '', '', 1, 'engin.yapici', '2015-12-13 18:12:49', '0000-00-00', 1, 'engin.yapici', '2015-12-13 18:12:49', 'Pending', 0),
(100050, 'test', 1, 'test', '1', 'Fisher Scientific', 'test', 134, '', '1234ZYZ', 'Project 2', '9876ABCD', 'ABCD12345XYZ', 'test', '', '', 1, 'engin.yapici', '2015-12-13 18:53:59', '0000-00-00', 9, 'john.doe', '2015-12-14 00:00:52', 'Pending', 0),
(100051, 'test', 1, 'test', '1', 'Fisher Scientific', 'test', 134, '', '9876ABCD', 'Project 1', '1234ZYZ', 'XYZ12345ABCD', 'test', '', '', 1, 'engin.yapici', '2015-12-13 18:56:33', '0000-00-00', 9, 'john.doe', '2015-12-13 23:23:52', 'Pending', 0),
(100053, 'Testing', 57, '50/Box', '3', 'VWR', 'DS65789', 450, '', '1234ZYZ', 'undefined', 'undefined', 'QWE4567890', 'Testing', '', '', 9, 'john.doe', '2015-12-13 23:40:03', '0000-00-00', 9, 'john.doe', '2015-12-13 23:40:03', 'Pending', 0),
(100052, 'Item Description', 5, '12 per Pack', '3', 'VWR', '12-15-4567', 405.88, '', '9876ABCD', 'Project 2', '9876ABCD', 'ABCD12345XYZ', 'testing', '', '', 1, 'engin.yapici', '2015-12-13 22:38:55', '0000-00-00', 9, 'john.doe', '2015-12-15 06:54:58', 'Pending', 0),
(100054, 'This item', 4, '100/Ea', '3', 'VWR', 'SG09876543', 230, '', '1234ZYZ', 'Project 2', '9876ABCD', 'XYZ12345ABCD', 'Testing', '', '', 9, 'john.doe', '2015-12-13 23:41:11', '0000-00-00', 9, 'john.doe', '2015-12-14 09:09:32', 'Pending', 0),
(100055, 'Item', 3, 'test', '3', 'VWR', 'test', 3, '', '9876ABCD', 'Project 2', '9876ABCD', 'XYZ12345ABCD', 'test', '', '', 9, 'john.doe', '2015-12-14 13:05:46', '0000-00-00', 9, 'john.doe', '2015-12-15 06:55:22', 'Pending', 0),
(100056, 'Description', 2, 'test', '3', 'VWR', 'test', 35, '', '1234ZYZ', 'Project 2', '9876ABCD', 'XYZ12345ABCD', 'test', '', '', 9, 'john.doe', '2015-12-14 13:16:44', '1969-12-31', 9, 'john.doe', '2015-12-15 06:55:32', 'Pending', 0),
(100057, 'test', 3, 'test', '3', 'VWR', 'test', 33, '', '1234ZYZ', 'undefined', 'undefined', 'test', 'test', '', '', 9, 'john.doe', '2015-12-14 13:18:43', '1969-12-31', 9, 'john.doe', '2015-12-14 13:18:43', 'Pending', 0),
(100058, 'test', 3, 'test', '3', 'VWR', 'test', 3, '', '1234ZYZ', 'Project 1', '1234ZYZ', 'ABCD12345XYZ', 'test', '', '', 9, 'john.doe', '2015-12-14 13:26:21', '2015-12-10', 9, 'john.doe', '2015-12-14 13:43:07', 'Pending', 0),
(100059, 'test', 3, 'test', '3', 'VWR', 'test', 3, '', '9876ABCD', 'Project 2', '9876ABCD', 'XYZ12345ABCD', 'test', '', '', 9, 'john.doe', '2015-12-14 13:26:45', '2015-12-10', 9, 'john.doe', '2015-12-14 14:07:17', 'Pending', 0),
(100060, 'test', 3, 'test', '3', 'VWR', 'test', 3, 'http://', '9876ABCD', 'Project 2', '9876ABCD', 'XYZ12345ABCD', '', '', '', 9, 'john.doe', '2015-12-14 13:28:52', '2015-12-15', 9, 'john.doe', '2015-12-19 17:12:22', 'Pending', 0),
(100061, 'test', 3, 'test', '2', 'Sigma-Aldrich', 'test', 3, 'http://sigma', '1234ZYZ', 'Project 2', '9876ABCD', 'XYZ12345ABCD', 'test', '', '', 9, 'john.doe', '2015-12-14 13:29:15', '2015-12-15', 9, 'john.doe', '2015-12-19 17:06:50', 'Pending', 0),
(100062, 'ere', 4, 'erer', '2', 'Sigma-Aldrich', 'er', 4, '', '', '', '', '', '', '', '', 9, 'john.doe', '2015-12-14 14:51:16', '2015-12-09', 9, 'john.doe', '2015-12-17 09:35:11', 'Pending', 0),
(100063, 'Testing', 4, 'Testing', '3', 'VWR', 'Testing', 44.44, '', '1234ZYZ', 'Project 1', '1234ZYZ', 'ABCD12345XYZ', 'Testing', '', '', 9, 'john.doe', '2015-12-14 14:56:03', '2015-12-08', 9, 'john.doe', '2015-12-16 17:43:48', 'Pending', 0),
(100064, 'test', 3, 'test', '3', 'VWR', 'test', 345, '', '', '', '', '', '', '', '', 1, 'engin.yapici', '2015-12-15 14:03:20', '2015-12-31', 1, 'engin.yapici', '2015-12-15 14:03:20', 'Pending', 0),
(100065, 'Testing', 1, 'Test', '1', 'Fisher Scientific', 'Test', 45, '', '9876ABCD', 'Project 2', '9876ABCD', 'XYZ12345ABCD', 'Testing', '', '', 1, 'engin.yapici', '2015-12-16 17:55:50', '2015-12-24', 9, 'john.doe', '2015-12-17 09:34:57', 'Pending', 0),
(100066, 'Test', 1, '5', '1', 'Fisher Scientific', 'Test', 678, '', '', '', '', '', '', '', '', 1, 'engin.yapici', '2015-12-17 06:53:07', '2015-12-26', 1, 'engin.yapici', '2015-12-17 06:53:07', 'Pending', 0),
(100067, 'Test', 4, '5', '1', 'Fisher Scientific', 'Test', 4, '', '', '', '', '', '', '', '', 1, 'engin.yapici', '2015-12-17 06:58:17', '2015-12-19', 1, 'engin.yapici', '2015-12-17 06:58:17', 'Pending', 0),
(100068, 'Test', 4, 'test', '2', 'Sigma-Aldrich', 'Test', 456, 'http://', '1234ZYZ', 'Project 2', '9876ABCD', 'XYZ12345ABCD', '', '', '', 1, 'engin.yapici', '2015-12-17 06:59:37', '2015-12-19', 9, 'john.doe', '2015-12-19 17:08:15', 'Pending', 0),
(100069, 'Test', 4, 'test', '3', 'VWR', 'test', 5678, 'http://fishersci.com', '', '', '', 'ABCD12345XYZ', '', '', '', 1, 'engin.yapici', '2015-12-17 07:00:32', '2015-12-03', 9, 'john.doe', '2015-12-19 17:03:32', 'Pending', 0),
(100070, 'test', 5, 'test', '2', 'Sigma-Aldrich', 'test', 76, '', '1234ZYZ', 'Project 2', '1234ZYZ', 'XYZ12345ABCD', 'test', '', '', 1, 'engin.yapici', '2015-12-17 07:01:08', '2015-12-10', 1, 'engin.yapici', '2015-12-17 07:01:08', 'Pending', 0),
(100071, 'Testing', 4, 'Test', '15', 'Bio-Rad', '98765', 500, 'http://biorad.com', '', '', '', '', '', '', '', 1, 'engin.yapici', '2015-12-17 08:02:38', '2015-12-24', 9, 'john.doe', '2015-12-17 17:34:43', 'Pending', 0),
(100072, 'Test', 3, 'Test', '3', 'VWR', '3456789', 45, 'http://', '9876ABCD', 'Project 2', '9876ABCD', 'ABCD12345XYZ', '', '', '', 9, 'john.doe', '2015-12-17 09:35:57', '2015-12-31', 9, 'john.doe', '2015-12-19 17:14:52', 'Pending', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(300) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activation` varchar(100) NOT NULL,
  `last_login_date` date NOT NULL,
  `account_status` int(11) NOT NULL DEFAULT '0',
  `user_type` int(1) NOT NULL DEFAULT '0',
  `forgot_password` varchar(100) NOT NULL DEFAULT '0',
  `password_reset` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `registration_date`, `activation`, `last_login_date`, `account_status`, `user_type`, `forgot_password`, `password_reset`) VALUES
(1, 'Engin', 'Yapici', 'engin.yapici', 'engin.yapici@example.com', '$2y$10$2TdVIQym8TUWkk1xhtBI5OOA9Z6xftytSAhrM.kcs64If4b5AjG3e', '2014-11-04 16:45:16', '', '2015-12-19', 1, 0, 'qetx96H4wiAYJToQSsVfOLnr5aI1vuz032XklZWcPbCB7mDyNEUhFdpR8KMg', 0),
(9, 'John', 'Doe', 'john.doe', 'john.doe@example.com', '$2y$10$2TdVIQym8TUWkk1xhtBI5OOA9Z6xftytSAhrM.kcs64If4b5AjG3e', '2015-10-23 20:27:20', '', '2015-12-19', 1, 1, '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE IF NOT EXISTS `vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `contact_person` varchar(200) NOT NULL,
  `approved` int(1) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  `added_by_user_id` int(11) NOT NULL,
  `added_by_username` varchar(100) NOT NULL,
  `last_updated_by_user_id` int(11) NOT NULL,
  `last_updated_by_username` varchar(100) NOT NULL,
  `last_updated_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `name`, `phone`, `address`, `website`, `contact_person`, `approved`, `date_added`, `added_by_user_id`, `added_by_username`, `last_updated_by_user_id`, `last_updated_by_username`, `last_updated_date`) VALUES
(1, 'Fisher Scientific', '1-800-766-7000', '4500 Turnberry Dr, Hanover Park, IL 60133', 'https://www.fishersci.com/', 'Jane Doe', 1, '0000-00-00 00:00:00', 0, '', 9, 'john.doe', '2015-12-19 21:51:28'),
(2, 'Sigma-Aldrich', '1-800-325-3010', '6000 N Teutonia Ave, Milwaukee, WI 53209', 'http://www.sigmaaldrich.com/', '', 1, '0000-00-00 00:00:00', 0, '', 9, 'john.doe', '2015-12-19 21:51:28'),
(3, 'VWR', '1-800-932-5000', '800 East Fabyan Parkway, Batavia, IL 60510', 'https://us.vwr.com/', '', 1, '0000-00-00 00:00:00', 0, '', 9, 'john.doe', '2015-12-19 21:51:28'),
(4, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 1, '2015-12-17 07:44:53', 1, 'engin.yapici', 9, 'john.doe', '2015-12-19 22:01:23'),
(5, 'CisBio', '1-888-963-4567', '135 South Road Bedford, MA 01730, USA', 'http://www.cisbio.com/', '', 1, '2015-12-17 07:46:45', 1, 'engin.yapici', 9, 'john.doe', '2015-12-19 22:01:22'),
(6, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 07:50:25', 1, 'engin.yapici', 9, 'john.doe', '2015-12-19 22:07:20'),
(7, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 07:50:50', 1, 'engin.yapici', 9, 'john.doe', '2015-12-19 21:51:28'),
(8, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 07:52:57', 1, 'engin.yapici', 1, '0', '2015-12-17 07:52:57'),
(9, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 07:53:59', 1, 'engin.yapici', 1, '0', '2015-12-17 07:53:59'),
(10, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 07:57:02', 1, 'engin.yapici', 1, '0', '2015-12-17 07:57:02'),
(11, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 07:58:47', 1, 'engin.yapici', 1, '0', '2015-12-17 07:58:47'),
(12, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 07:59:46', 1, 'engin.yapici', 1, '0', '2015-12-17 07:59:46'),
(13, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 08:00:30', 1, 'engin.yapici', 1, '0', '2015-12-17 08:00:30'),
(14, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 08:00:56', 1, 'engin.yapici', 1, '0', '2015-12-17 08:00:56'),
(15, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 0, '2015-12-17 08:02:38', 1, 'engin.yapici', 1, '0', '2015-12-17 08:02:38');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
