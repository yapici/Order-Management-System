-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 05, 2016 at 01:40 PM
-- Server version: 5.5.45-cll-lve
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `oms_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_trail`
--

CREATE TABLE IF NOT EXISTS `audit_trail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changed_table` varchar(20) NOT NULL,
  `changed_item_id` int(11) NOT NULL,
  `changed_field_name` varchar(100) NOT NULL,
  `old_value` varchar(1000) NOT NULL,
  `new_value` varchar(1000) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `audit_trail`
--

INSERT INTO `audit_trail` (`id`, `changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `date`, `user_id`) VALUES
(1, 'cost_centers', 6, 'NEW_ITEM', 'NEW_ITEM', 'test', '2016-01-05 14:30:41', 9),
(2, 'orders', 100124, 'NEW_ITEM', 'NEW_ITEM', '1000 uL Filter Tips, Sterile', '2016-01-05 14:31:08', 9),
(3, 'cost_centers', 6, 'name', 'test', 'testdf', '2016-01-05 16:24:10', 9),
(4, 'orders', 100124, 'description', '1000 uL Filter Tips, Sterile', '1000 uL Filter Tips, Steriler', '2016-01-05 16:33:44', 9),
(5, 'orders', 100124, 'quantity', '2', '24', '2016-01-05 16:34:44', 9),
(6, 'orders', 100124, 'description', '1000 uL Filter Tips, Steriler', '1000 uL Filter Tips, Steriler4', '2016-01-05 16:34:53', 9),
(7, 'orders', 100125, 'description', 'Test', 'Test1', '2016-01-05 20:04:21', 9),
(8, 'orders', 100125, 'quantity', '0', '2', '2016-01-05 20:04:21', 9),
(9, 'orders', 100125, 'uom', 'Test', '2Test', '2016-01-05 20:04:21', 9),
(10, 'orders', 100114, 'description', 'SATWIPES NW 4x4 70 IPA', 'SATWIPES NW 4x4 70 IPA1', '2016-01-05 20:18:52', 9),
(11, 'orders', 100114, 'quantity', '1', '11', '2016-01-05 20:18:52', 9),
(12, 'orders', 100114, 'uom', '185/PK', '185/PK1', '2016-01-05 20:18:52', 9),
(13, 'orders', 100114, 'vendor', '2', '4', '2016-01-05 20:18:52', 9),
(14, 'orders', 100114, 'vendor_name', 'Sigma-Aldrich', 'Bio-Rad', '2016-01-05 20:18:52', 9),
(15, 'orders', 100114, 'catalog_no', '19-170-951', '19-170-9511', '2016-01-05 20:18:52', 9),
(16, 'orders', 100114, 'price', '248.47000122070312', '248.4709930419922', '2016-01-05 20:18:52', 9),
(17, 'orders', 100114, 'weblink', 'http://dfd', 'http://dfd1', '2016-01-05 20:18:52', 9),
(18, 'orders', 100114, 'cost_center', '1', '2', '2016-01-05 20:18:52', 9),
(19, 'orders', 100114, 'project', '1', '2', '2016-01-05 20:18:52', 9),
(20, 'orders', 100114, 'comments', 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.1', '2016-01-05 20:18:52', 9),
(21, 'orders', 100114, 'vendor_order_no', '', '1', '2016-01-05 20:18:52', 9),
(22, 'orders', 100114, 'invoice_no', '', '1', '2016-01-05 20:18:52', 9),
(23, 'orders', 100114, 'status', 'Pending', 'Processing', '2016-01-05 20:18:52', 9),
(24, 'vendors', 63, 'NEW_ITEM', 'NEW_ITEM', 'df', '2016-01-05 20:30:52', 9),
(25, 'vendors', 63, 'name', 'df', 'df1', '2016-01-05 20:30:54', 9),
(26, 'vendors', 63, 'phone', 'sdfg', 'sdfg1', '2016-01-05 20:30:55', 9),
(27, 'vendors', 63, 'website', '', '1', '2016-01-05 20:30:56', 9),
(28, 'vendors', 63, 'address', '', '1', '2016-01-05 20:30:57', 9),
(29, 'vendors', 63, 'contact_person', '', '1', '2016-01-05 20:30:57', 9),
(30, 'vendors', 63, 'approved', '1', '0', '2016-01-05 20:31:02', 9),
(31, 'vendors', 63, 'deleted', '0', '1', '2016-01-05 20:31:03', 9),
(32, 'vendors', 62, 'contact_person', 'test3', 'test31', '2016-01-05 20:31:29', 9),
(33, 'vendors', 62, 'account_number', 'test31', 'test3', '2016-01-05 20:32:26', 9),
(34, 'users', 10, 'phone', '', '1', '2016-01-05 20:32:45', 9),
(35, 'users', 10, 'account_status', '1', '0', '2016-01-05 20:32:46', 9),
(36, 'users', 10, 'account_status', '0', '1', '2016-01-05 20:35:54', 9),
(37, 'users', 10, 'user_type', '0', '2', '2016-01-05 20:35:56', 9),
(38, 'users', 9, 'last_login_date', '2016-01-05 14:04:13', '2016-01-05 14:36:12', '2016-01-05 20:36:13', 9),
(39, 'projects', 3, 'name', 'testdf', 'testdf1', '2016-01-05 20:36:35', 9),
(40, 'projects', 3, 'number', 'test', 'test1', '2016-01-05 20:36:36', 9),
(41, 'projects', 3, 'active', '0', '1', '2016-01-05 20:36:39', 9),
(42, 'projects', 4, 'NEW_ITEM', 'NEW_ITEM', '1', '2016-01-05 20:36:41', 9),
(43, 'cost_centers', 6, 'name', 'testdf', 'testdf1', '2016-01-05 20:37:01', 9),
(44, 'cost_centers', 7, 'NEW_ITEM', 'NEW_ITEM', '1', '2016-01-05 20:37:03', 9),
(45, 'cost_centers', 7, 'active', '0', '1', '2016-01-05 20:38:42', 9),
(46, 'cost_centers', 7, 'name', '1', '12', '2016-01-05 20:38:45', 9);

-- --------------------------------------------------------

--
-- Table structure for table `cost_centers`
--

CREATE TABLE IF NOT EXISTS `cost_centers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `date_added` datetime NOT NULL,
  `added_by_user_id` int(11) NOT NULL,
  `added_by_username` varchar(100) NOT NULL,
  `last_updated_date` datetime NOT NULL,
  `last_updated_by_user_id` int(11) NOT NULL,
  `last_updated_by_username` varchar(100) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `cost_centers`
--

INSERT INTO `cost_centers` (`id`, `name`, `date_added`, `added_by_user_id`, `added_by_username`, `last_updated_date`, `last_updated_by_user_id`, `last_updated_by_username`, `active`) VALUES
(1, '1234ZYZ', '0000-00-00 00:00:00', 0, '', '2015-12-29 17:19:43', 9, 'john.doe', 1),
(2, '9876ABCDs', '0000-00-00 00:00:00', 0, '', '2015-12-29 16:57:04', 9, 'john.doe', 1),
(3, 'et', '2015-12-29 17:15:55', 9, 'john.doe', '2015-12-29 19:27:45', 9, 'john.doe', 0),
(4, 'dddf', '2015-12-29 17:16:33', 9, 'john.doe', '2015-12-30 12:36:44', 9, 'john.doe', 0),
(5, 'dsfd', '2015-12-30 12:36:51', 9, 'john.doe', '2015-12-30 12:36:51', 9, 'john.doe', 0),
(6, 'testdf1', '2016-01-05 08:30:41', 9, 'john.doe', '2016-01-05 14:37:02', 9, 'john.doe', 1),
(7, '12', '2016-01-05 14:37:03', 9, 'john.doe', '2016-01-05 14:38:45', 9, 'john.doe', 1);

--
-- Triggers `cost_centers`
--
DROP TRIGGER IF EXISTS `after_insert_cost_centers`;
DELIMITER //
CREATE TRIGGER `after_insert_cost_centers` AFTER INSERT ON `cost_centers`
 FOR EACH ROW INSERT INTO audit_trail 
            (`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
        VALUES 
            ("cost_centers", NEW.id, "NEW_ITEM", "NEW_ITEM", NEW.name, NEW.added_by_user_id)
//
DELIMITER ;
DROP TRIGGER IF EXISTS `after_update_cost_centers`;
DELIMITER //
CREATE TRIGGER `after_update_cost_centers` AFTER UPDATE ON `cost_centers`
 FOR EACH ROW begin
IF OLD.name != NEW.name THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES 
        ('cost_centers', OLD.id, 'name', OLD.name, NEW.name, NEW.last_updated_by_user_id);
END IF;

IF OLD.active != NEW.active THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES 
        ('cost_centers', OLD.id, 'active', OLD.active, NEW.active, NEW.last_updated_by_user_id);
END IF;
end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(300) NOT NULL,
  `quantity` int(100) NOT NULL,
  `uom` varchar(100) NOT NULL,
  `vendor` varchar(100) NOT NULL,
  `vendor_name` varchar(200) NOT NULL,
  `catalog_no` varchar(200) NOT NULL,
  `price` float NOT NULL,
  `weblink` text NOT NULL,
  `cost_center` int(11) NOT NULL DEFAULT '0',
  `project` int(11) DEFAULT '0',
  `account_id` int(11) NOT NULL,
  `comments` varchar(1000) NOT NULL,
  `vendor_order_no` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `requested_by_id` int(100) NOT NULL,
  `requested_by_username` varchar(100) NOT NULL,
  `requested_datetime` datetime NOT NULL,
  `item_needed_by_date` date NOT NULL,
  `last_updated_by_id` int(100) NOT NULL,
  `last_updated_by_username` varchar(100) NOT NULL,
  `last_updated_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` varchar(100) NOT NULL,
  `status_updated_date` datetime NOT NULL,
  `status_updated_by_user_id` int(11) NOT NULL,
  `status_updated_by_username` varchar(100) NOT NULL,
  `ordered` int(1) NOT NULL DEFAULT '0',
  `ordered_date` datetime NOT NULL,
  `ordered_by_user_id` int(11) NOT NULL,
  `ordered_by_username` varchar(100) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=100126 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `description`, `quantity`, `uom`, `vendor`, `vendor_name`, `catalog_no`, `price`, `weblink`, `cost_center`, `project`, `account_id`, `comments`, `vendor_order_no`, `invoice_no`, `requested_by_id`, `requested_by_username`, `requested_datetime`, `item_needed_by_date`, `last_updated_by_id`, `last_updated_by_username`, `last_updated_datetime`, `status`, `status_updated_date`, `status_updated_by_user_id`, `status_updated_by_username`, `ordered`, `ordered_date`, `ordered_by_user_id`, `ordered_by_username`, `deleted`) VALUES
(100000, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://', 1, 1, 1, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', 'fgfg', 'ddwg', 1, 'engin.yapici', '2015-10-15 13:26:50', '0000-00-00', 9, 'john.doe', '2015-12-31 16:54:41', 'Backordered', '2015-10-15 13:26:50', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100001, 'Kimtech Sterile Sleeves', 1, '200/CS', '2', 'Sigma-Aldrich', '17-150-200', 218.03, 'http://', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-10-15 13:31:19', '0000-00-00', 9, 'john.doe', '2015-12-24 12:12:12', 'Processing', '2015-10-15 13:31:19', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100002, '1000 uL Filter Tips, Sterile', 2, '960/PK', '2', 'Sigma-Aldrich', '02-707-404PM', 306.22, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-10-15 13:44:46', '0000-00-00', 9, 'john.doe', '2015-10-22 11:32:36', 'Received', '2015-10-15 13:44:46', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100003, 'test', 0, 'test', '2', 'Sigma-Aldrich', 'test', 50, 'http://', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-10-26 12:49:49', '0000-00-00', 9, 'john.doe', '2015-12-24 12:12:47', 'Processing', '2015-10-26 12:49:49', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100004, 'tesst', 0, 'test', '2', 'Sigma-Aldrich', 'dsgsdfgh', 60, 'http://', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-10-26 12:53:09', '0000-00-00', 9, 'john.doe', '2015-12-24 12:13:33', 'Ordered', '2015-10-26 12:53:09', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100005, 'Nalgene Rapid-Flow Sterile Disposable Filter Units', 1, 'Case of 12', '2', 'Sigma-Aldrich', '09-740-28C', 217.9, 'http://', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-11-23 14:16:11', '0000-00-00', 9, 'john.doe', '2015-12-24 12:12:53', 'Delivered', '2015-11-23 14:16:11', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100006, 'Test1', 13, 'Case of 13', '2', 'Sigma-Aldrich', '12345678', 25, '', 1, 1, 1, 'The standard chundfdfdk odfdsgfsgfsf Lodfdfdfdfdrem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 9, 'john.doe', '2015-12-14 10:13:42', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100007, 'Test2', 1, 'Case of 14', '2', 'Sigma-Aldrich', '12345679', 26, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100008, 'Test3', 1, 'Case of 15', '2', 'Sigma-Aldrich', '12345680', 27, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100009, 'Test4', 1, 'Case of 16', '2', 'Sigma-Aldrich', '12345681', 28, 'http://', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 9, 'john.doe', '2015-12-24 12:13:44', 'Delivered', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100010, 'Test5', 1, 'Case of 17', '2', 'Sigma-Aldrich', '12345682', 29, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100011, 'Test6', 1, 'Case of 18', '2', 'Sigma-Aldrich', '12345683', 30, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 9, 'john.doe', '2015-12-14 09:15:33', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100012, 'Test7', 1, 'Case of 19', '2', 'Sigma-Aldrich', '12345684', 31, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 9, 'john.doe', '2015-12-14 09:17:40', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100013, 'Test8', 1, 'Case of 20', '2', 'Sigma-Aldrich', '12345685', 32, 'http://', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-01-15 14:16:00', '0000-00-00', 9, 'john.doe', '2015-12-24 12:53:20', 'Processing', '2012-01-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100014, 'Test9', 1, 'Case of 21', '2', 'Sigma-Aldrich', '12345686', 33, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-02-15 14:16:00', '0000-00-00', 1, '', '2012-02-15 14:16:00', 'Pending', '2012-02-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100015, 'Test10', 1, 'Case of 22', '2', 'Sigma-Aldrich', '12345687', 34, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-03-15 14:16:00', '0000-00-00', 1, '', '2012-03-15 14:16:00', 'Pending', '2012-03-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100016, 'Test11', 1, 'Case of 23', '2', 'Sigma-Aldrich', '12345688', 35, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-04-15 14:16:00', '0000-00-00', 1, '', '2012-04-15 14:16:00', 'Pending', '2012-04-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100017, 'Test12', 1, 'Case of 24', '2', 'Sigma-Aldrich', '12345689', 36, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-05-15 14:16:00', '0000-00-00', 1, '', '2012-05-15 14:16:00', 'Pending', '2012-05-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100018, 'Test13', 1, 'Case of 25', '2', 'Sigma-Aldrich', '12345690', 37, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-06-15 14:16:00', '0000-00-00', 1, '', '2012-06-15 14:16:00', 'Pending', '2012-06-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100019, 'Test14', 1, 'Case of 26', '2', 'Sigma-Aldrich', '12345691', 38, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-07-15 14:16:00', '0000-00-00', 1, '', '2012-07-15 14:16:00', 'Pending', '2012-07-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100020, 'Test15', 1, 'Case of 27', '2', 'Sigma-Aldrich', '12345692', 39, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-08-15 14:16:00', '0000-00-00', 1, '', '2012-08-15 14:16:00', 'Pending', '2012-08-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100021, 'Test16', 1, 'Case of 28', '2', 'Sigma-Aldrich', '12345693', 40, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-09-15 14:16:00', '0000-00-00', 1, '', '2012-09-15 14:16:00', 'Pending', '2012-09-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100022, 'Test17', 1, 'Case of 29', '2', 'Sigma-Aldrich', '12345694', 41, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-10-15 14:16:00', '0000-00-00', 1, '', '2012-10-15 14:16:00', 'Pending', '2012-10-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100023, 'Test18', 1, 'Case of 30', '1', 'Fisher Scientific', '12345695', 42, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-11-15 14:16:00', '0000-00-00', 1, '', '2012-11-15 14:16:00', 'Pending', '2012-11-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100024, 'Test19', 1, 'Case of 31', '1', 'Fisher Scientific', '12345696', 43, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2012-12-15 14:16:00', '0000-00-00', 1, '', '2012-12-15 14:16:00', 'Pending', '2012-12-15 14:16:00', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100025, 'Test20', 1, 'Case of 32', '1', 'Fisher Scientific', '12345697', 44, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100026, 'Test21', 1, 'Case of 33', '1', 'Fisher Scientific', '12345698', 45, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100027, 'Test22', 1, 'Case of 34', '1', 'Fisher Scientific', '12345699', 46, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100028, 'Test23', 1, 'Case of 35', '1', 'Fisher Scientific', '12345700', 47, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100029, 'Test24', 1, 'Case of 36', '1', 'Fisher Scientific', '12345701', 48, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100030, 'Test25', 1, 'Case of 37', '1', 'Fisher Scientific', '12345702', 49, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100031, 'Test26', 1, 'Case of 38', '1', 'Fisher Scientific', '12345703', 50, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100032, 'Test27', 1, 'Case of 39', '1', 'Fisher Scientific', '12345704', 51, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100033, 'Test28', 1, 'Case of 40', '1', 'Fisher Scientific', '12345705', 52, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100034, 'Test29', 1, 'Case of 41', '1', 'Fisher Scientific', '12345706', 53, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100035, 'Test30', 1, 'Case of 42', '1', 'Fisher Scientific', '12345707', 54, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100036, 'Test31', 1, 'Case of 43', '1', 'Fisher Scientific', '12345708', 55, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100037, 'Test32', 1, 'Case of 44', '1', 'Fisher Scientific', '12345709', 56, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100038, 'Test33', 1, 'Case of 45', '1', 'Fisher Scientific', '12345710', 57, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100039, 'Test34', 1, 'Case of 46', '1', 'Fisher Scientific', '12345711', 58, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100040, 'Test35', 1, 'Case of 47', '1', 'Fisher Scientific', '12345712', 59, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100041, 'Test36', 1, 'Case of 48', '1', 'Fisher Scientific', '12345713', 60, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100042, 'Test37', 1, 'Case of 49', '1', 'Fisher Scientific', '12345714', 61, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100043, 'Test38', 1, 'Case of 50', '1', 'Fisher Scientific', '12345715', 62, '', 1, 1, 1, 'None', '', '', 1, 'engin.yapici', '2015-12-12 18:04:13', '0000-00-00', 1, '', '0000-00-00 00:00:00', 'Pending', '2015-12-12 18:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100044, 'Item 4578', 5, '12/Box', '1', 'Fisher Scientific', '098765432', 567, '', 1, 1, 1, 'Testing', '', '', 1, 'engin.yapici', '2015-12-12 23:02:50', '0000-00-00', 9, 'john.doe', '2015-12-13 23:34:22', 'Pending', '2015-12-12 23:02:50', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100045, 'testing', 1, '12', '1', 'Fisher Scientific', '12345', 0, '', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-12-12 23:04:13', '0000-00-00', 1, 'engin.yapici', '2015-12-12 23:04:13', 'Pending', '2015-12-12 23:04:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100046, 'test', 1, '12', '1', 'Fisher Scientific', '1234', 75, '', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-12-12 23:10:24', '0000-00-00', 1, 'engin.yapici', '2015-12-12 23:10:24', 'Pending', '2015-12-12 23:10:24', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100047, 'test', 0, 'test', '1', 'Fisher Scientific', 'test', 54, '', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-12-12 23:16:41', '0000-00-00', 9, 'john.doe', '2015-12-14 10:11:48', 'Pending', '2015-12-12 23:16:41', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100048, 'test', 1, 'test', '1', 'Fisher Scientific', 'test', 2345, '', 1, 1, 1, 'testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttest', '', '', 1, 'engin.yapici', '2015-12-12 23:22:45', '0000-00-00', 1, 'engin.yapici', '2015-12-12 23:22:45', 'Pending', '2015-12-12 23:22:45', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100049, 'test', 5, 'test', '1', 'Fisher Scientific', 'test', 4, 'http://', 2, 2, 1, 'test', '', '', 1, 'engin.yapici', '2015-12-13 18:12:49', '0000-00-00', 9, 'john.doe', '2015-12-29 18:22:08', 'Pending', '2015-12-13 18:12:49', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100050, 'test', 1, 'test', '1', 'Fisher Scientific', 'test', 134, '', 1, 1, 1, 'test', '', '', 1, 'engin.yapici', '2015-12-13 18:53:59', '0000-00-00', 9, 'john.doe', '2015-12-14 00:00:52', 'Pending', '2015-12-13 18:53:59', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100051, 'test', 1, 'test', '1', 'Fisher Scientific', 'test', 134, '', 1, 1, 1, 'test', '', '', 1, 'engin.yapici', '2015-12-13 18:56:33', '0000-00-00', 9, 'john.doe', '2015-12-13 23:23:52', 'Pending', '2015-12-13 18:56:33', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100053, 'Testing', 57, '50/Box', '3', 'VWR', 'DS65789', 450, '', 1, 1, 1, 'Testing', '', '', 9, 'john.doe', '2015-12-13 23:40:03', '0000-00-00', 9, 'john.doe', '2015-12-13 23:40:03', 'Pending', '2015-12-13 23:40:03', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100052, 'Item Description', 5, '12 per Pack', '3', 'VWR', '12-15-4567', 405.88, '', 1, 1, 1, 'testing', '', '', 1, 'engin.yapici', '2015-12-13 22:38:55', '0000-00-00', 9, 'john.doe', '2015-12-15 06:54:58', 'Pending', '2015-12-13 22:38:55', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100054, 'This item', 4, '100/Ea', '3', 'VWR', 'SG09876543', 230, 'http://', 1, 1, 1, 'Testing', '', '', 9, 'john.doe', '2015-12-13 23:41:11', '0000-00-00', 9, 'john.doe', '2015-12-21 13:22:45', 'Pending', '2015-12-13 23:41:11', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100055, 'Item', 3, 'test', '3', 'VWR', 'test', 3, '', 1, 1, 1, 'test', '', '', 9, 'john.doe', '2015-12-14 13:05:46', '0000-00-00', 9, 'john.doe', '2015-12-15 06:55:22', 'Pending', '2015-12-14 13:05:46', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100056, 'Description', 2, 'test', '3', 'VWR', 'test', 35, '', 1, 1, 1, 'test', '', '', 9, 'john.doe', '2015-12-14 13:16:44', '1969-12-31', 9, 'john.doe', '2015-12-15 06:55:32', 'Pending', '2015-12-14 13:16:44', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 1),
(100057, 'test', 3, 'test', '3', 'VWR', 'test', 33, '', 1, 1, 1, 'test', '', '', 9, 'john.doe', '2015-12-14 13:18:43', '1969-12-31', 9, 'john.doe', '2015-12-14 13:18:43', 'Pending', '2015-12-14 13:18:43', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 1),
(100058, 'test', 3, 'test', '3', 'VWR', 'test', 3, '', 1, 1, 1, 'test', '', '', 9, 'john.doe', '2015-12-14 13:26:21', '2015-12-10', 9, 'john.doe', '2015-12-14 13:43:07', 'Pending', '2015-12-14 13:26:21', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100059, 'test', 3, 'test', '3', 'VWR', 'test', 3, '', 1, 1, 1, 'test', '', '', 9, 'john.doe', '2015-12-14 13:26:45', '2015-12-10', 9, 'john.doe', '2015-12-14 14:07:17', 'Pending', '2015-12-14 13:26:45', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100060, 'test', 3, 'test', '3', 'VWR', 'test', 3, 'http://', 1, 1, 1, '', '', '', 9, 'john.doe', '2015-12-14 13:28:52', '2015-12-15', 9, 'john.doe', '2015-12-19 17:12:22', 'Pending', '2015-12-14 13:28:52', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100061, 'test', 3, 'test', '2', 'Sigma-Aldrich', 'test', 3, 'http://sigma', 1, 1, 1, 'test', '', '', 9, 'john.doe', '2015-12-14 13:29:15', '2015-12-15', 9, 'john.doe', '2015-12-19 17:06:50', 'Pending', '2015-12-14 13:29:15', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100062, 'ere', 4, 'erer', '2', 'Sigma-Aldrich', 'er', 4, 'http://', 1, 2, 1, '', '', '', 9, 'john.doe', '2015-12-14 14:51:16', '2015-12-09', 9, 'john.doe', '2015-12-20 20:57:09', 'Pending', '2015-12-14 14:51:16', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100063, 'Testing', 4, 'Testing', '3', 'VWR', 'Testing', 44.44, '', 1, 1, 2, 'Testing', '', '', 9, 'john.doe', '2015-12-14 14:56:03', '2015-12-08', 9, 'john.doe', '2015-12-16 17:43:48', 'Pending', '2015-12-14 14:56:03', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100064, 'test', 3, 'test', '3', 'VWR', 'test', 345, '', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-12-15 14:03:20', '2015-12-31', 1, 'engin.yapici', '2015-12-15 14:03:20', 'Pending', '2015-12-15 14:03:20', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100065, 'Testing', 1, 'Test', '1', 'Fisher Scientific', 'Test', 45, '', 1, 1, 1, 'Testing', '', '', 1, 'engin.yapici', '2015-12-16 17:55:50', '2015-12-24', 9, 'john.doe', '2015-12-17 09:34:57', 'Pending', '2015-12-16 17:55:50', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100066, 'Test', 1, '5', '1', 'Fisher Scientific', 'Test', 678, '', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-12-17 06:53:07', '2015-12-26', 1, 'engin.yapici', '2015-12-17 06:53:07', 'Pending', '2015-12-17 06:53:07', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100067, 'Test', 4, '5', '1', 'Fisher Scientific', 'Test', 4, '', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-12-17 06:58:17', '2015-12-19', 1, 'engin.yapici', '2015-12-17 06:58:17', 'Pending', '2015-12-17 06:58:17', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100068, 'Test', 4, 'test', '2', 'Sigma-Aldrich', 'Test', 456, 'http://', 1, 2, 1, '', '', '', 1, 'engin.yapici', '2015-12-17 06:59:37', '2015-12-19', 9, 'john.doe', '2015-12-19 17:08:15', 'Pending', '2015-12-17 06:59:37', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100069, 'Test', 4, 'test', '3', 'VWR', 'test', 5678, 'http://fishersci.com', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-12-17 07:00:32', '2015-12-03', 9, 'john.doe', '2015-12-19 17:03:32', 'Pending', '2015-12-17 07:00:32', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100070, 'test', 5, 'test', '2', 'Sigma-Aldrich', 'test', 76, '', 1, 1, 1, 'test', '', '', 1, 'engin.yapici', '2015-12-17 07:01:08', '2015-12-10', 1, 'engin.yapici', '2015-12-17 07:01:08', 'Pending', '2015-12-17 07:01:08', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100071, 'Testing', 4, 'Test', '1', 'Fisher Scientific', '98765', 500, 'http://biorad.com', 1, 1, 1, '', '', '', 1, 'engin.yapici', '2015-12-17 08:02:38', '2015-12-24', 9, 'john.doe', '2015-12-24 11:48:23', 'Pending', '2015-12-17 08:02:38', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100072, 'Test', 3, 'Test', '3', 'VWR', '3456789', 45, 'http://', 1, 1, 1, '', '', '', 9, 'john.doe', '2015-12-17 09:35:57', '2015-12-31', 1, 'engin.yapici', '2015-12-21 08:31:34', 'Pending', '2015-12-17 09:35:57', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100073, 'Testing', 3, 'Test', '5', 'CisBio', '1234567', 54, 'http://', 1, 1, 2, '', '', '', 9, 'john.doe', '2015-12-23 11:05:22', '2015-12-31', 9, 'john.doe', '2015-12-23 11:05:22', 'Pending', '2015-12-23 11:05:22', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100074, 'Testing', 3, 'Test', '5', 'CisBio', '1234567', 54, 'http://fff', 1, 1, 1, 'test', '', '', 9, 'john.doe', '2015-12-23 11:06:20', '2015-12-31', 9, 'john.doe', '2015-12-23 14:32:02', 'Pending', '2015-12-23 11:06:20', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100075, 'dsgsfddd', 3, 'erwer', '2', 'Sigma-Aldrich', 'ewr', 3, 'http://', 1, 2, 1, '', '', '', 9, 'john.doe', '2015-12-23 11:12:14', '2015-12-31', 9, 'john.doe', '2015-12-30 11:18:32', 'Pending', '2015-12-23 11:12:14', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100076, 'etwr', 4, '3434', '1', 'Fisher Scientific', '343e', 0, 'http://', 2, 1, 1, 'test', '1234567', '09876543', 1, 'engin.yapici', '2015-12-23 11:24:42', '2015-12-11', 9, 'john.doe', '2015-12-23 18:13:39', 'Pending', '2015-12-23 11:24:42', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100077, 'Test', 3, 'test', '3', 'VWR', 'test', 0, 'http://sigma.com', 2, 2, 2, 'test', '', '', 9, 'john.doe', '2015-12-23 18:14:44', '2016-01-21', 9, 'john.doe', '2015-12-24 12:31:52', 'Backordered', '2015-12-23 18:14:44', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100078, 'aaa', 4, 'aaa', '1', 'Fisher Scientific', 'aaa', 44, 'http://aaaa', 2, 2, 0, 'aaa', '', '', 9, 'john.doe', '2015-12-24 11:39:31', '2015-12-23', 9, 'john.doe', '2015-12-24 11:39:31', 'Pending', '0000-00-00 00:00:00', 0, '', 0, '0000-00-00 00:00:00', 0, '', 0),
(100079, 'ddd', 3, 'ddd', '5', 'CisBio', 'ddd', 76, 'http://ddd', 2, 1, 0, 'ddd', '', '', 9, 'john.doe', '2015-12-24 12:00:22', '2015-12-09', 9, 'john.doe', '2015-12-24 12:13:13', 'Processing', '2015-12-24 12:00:22', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100080, 'sfdf', 3, 'dfdf', '5', 'CisBio', 'dfdf', 76543, 'http://df', 0, 1, 0, 'dgfg', 'agty', 'testtest3 gg', 9, 'john.doe', '2015-12-24 12:30:47', '2015-12-01', 9, 'john.doe', '2015-12-28 12:06:28', 'Delivered', '2015-12-24 12:30:47', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100081, 'dddr', 34, '22', '1', 'Fisher Scientific', 'ddd3', 2, '', 2, 1, 0, '', '', '', 9, 'john.doe', '2015-12-28 08:15:54', '2015-12-31', 9, 'john.doe', '2015-12-28 08:15:54', 'Pending', '2015-12-28 08:15:54', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100082, 'eeeer', 34, '4334', '1', 'Fisher Scientific', 'eee', 33, '', 1, 2, 1, '', '', '', 9, 'john.doe', '2015-12-28 08:16:28', '2015-12-15', 9, 'john.doe', '2015-12-28 08:16:28', 'Pending', '2015-12-28 08:16:28', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100083, 'www', 2, 'www', '1', 'Fisher Scientific', 'www', 0, '', 0, 1, 0, '', '', '', 9, 'john.doe', '2015-12-28 08:17:39', '2015-12-16', 9, 'john.doe', '2015-12-28 08:17:39', 'Pending', '2015-12-28 08:17:39', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100084, 'fff', 3, 'fff', '1', 'Fisher Scientific', 'fff', 0, 'http://', 0, 2, 0, '', '987654321', '123456789', 9, 'john.doe', '2015-12-28 08:19:51', '2015-12-09', 9, 'john.doe', '2015-12-28 11:45:29', 'Pending', '2015-12-28 08:19:51', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100085, 'testingtesting this', 4, '3', '2', 'Sigma-Aldrich', '3', 0, 'http://', 1, 1, 0, '', '', '', 9, 'john.doe', '2015-12-28 11:30:19', '2015-12-08', 9, 'john.doe', '2015-12-29 18:21:43', 'Pending', '2015-12-28 11:30:19', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100086, 'testingtesting', 4, 'eee', '1', 'Fisher Scientific', 'ee', 0, 'http://', 2, 2, 0, 'Lorem ipsum dolor sit amet, mel sint conceptam vituperatoribus an. Ad ius habeo utamur eligendi. Eum ad mutat audire aeterno, ei sed virtute reformidans, sonet mentitum conceptam has et. Nihil laudem postea ex eam. Sit tale dictas consulatu ne. Quod aliquid euripidis sed et.', '', '', 9, 'john.doe', '2015-12-28 11:30:33', '2015-12-24', 9, 'john.doe', '2015-12-29 18:28:44', 'Pending', '2015-12-28 11:30:33', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100087, 'sfdgfdsgf', 435, 'gfegf', '5', 'CisBio', 'dgfgf', 0, 'http://cvgfsg', 2, 1, 0, '', '', '', 9, 'john.doe', '2015-12-29 15:29:04', '2015-12-24', 9, 'john.doe', '2015-12-29 18:28:32', 'Pending', '2015-12-29 15:29:04', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100088, 'fghgh', 4434, 'ghdgh', '1', 'Fisher Scientific', 'fgfg', 443, 'http://gfgfg', 1, 2, 0, 'fgfdg', 'hgdhfghj', 'dhgf', 1, 'engin.yapici', '2015-12-30 20:40:31', '2015-03-12', 9, 'john.doe', '2015-12-30 21:53:39', 'Processing', '2015-12-30 20:40:31', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100089, 'Testing', 3, 'Test', '5', 'CisBio', '1234567', 54, 'http://fff', 1, 1, 0, 'test', '', '', 9, 'john.doe', '2015-12-30 22:31:01', '1969-12-31', 9, 'john.doe', '2015-12-30 23:02:59', 'Processing', '2015-12-30 22:31:01', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100090, 'Testing', 3, 'Test', '5', 'CisBio', '1234567', 54, 'http://fddfdfdfd', 1, 1, 0, 'dsfsdf', '', '', 1, 'engin.yapici', '2015-12-31 11:07:23', '1969-12-31', 1, 'engin.yapici', '2015-12-31 11:07:23', 'Pending', '2015-12-31 11:07:23', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100091, 'sfdgfdsgf', 435, 'gfegf', '5', 'CisBio', 'dgfgf', 0, 'http://cvgfsg', 2, 1, 0, '', '', '', 9, 'john.doe', '2015-12-31 11:10:52', '1969-12-31', 9, 'john.doe', '2015-12-31 11:10:52', 'Pending', '2015-12-31 11:10:52', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100092, 'testingtesting', 4, 'eee', '1', 'Fisher Scientific', 'ee', 0, 'http://', 2, 2, 0, 'Lorem ipsum dolor sit amet, mel sint conceptam vituperatoribus an. Ad ius habeo utamur eligendi. Eum ad mutat audire aeterno, ei sed virtute reformidans, sonet mentitum conceptam has et. Nihil laudem postea ex eam. Sit tale dictas consulatu ne. Quod aliquid euripidis sed et.', '', '', 9, 'john.doe', '2015-12-31 11:15:05', '1969-12-31', 9, 'john.doe', '2015-12-31 11:15:05', 'Pending', '2015-12-31 11:15:05', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100093, 'sfdgfdsgf', 435, 'gfegf', '5', 'CisBio', 'dgfgf', 0, 'http://cvgfsg', 2, 1, 0, '', '', '', 9, 'john.doe', '2015-12-31 11:18:12', '2016-02-26', 9, 'john.doe', '2015-12-31 11:18:12', 'Pending', '2015-12-31 11:18:12', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100094, 'sfdf', 3, 'dfdf', '5', 'CisBio', 'dfdf', 76543, 'http://df', 2, 1, 0, 'dgfg', '', '', 9, 'john.doe', '2015-12-31 11:20:53', '2015-12-30', 9, 'john.doe', '2015-12-31 11:20:53', 'Pending', '2015-12-31 11:20:53', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100095, 'sfdf', 3, 'dfdf', '5', 'CisBio', 'dfdf', 76543, 'http://df', 2, 1, 0, 'dgfg', '', '', 9, 'john.doe', '2015-12-31 11:21:15', '2015-04-12', 9, 'john.doe', '2015-12-31 11:21:15', 'Pending', '2015-12-31 11:21:15', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100096, 'testingtesting', 4, 'eee', '1', 'Fisher Scientific', 'ee', 0, 'http://', 2, 2, 0, 'Lorem ipsum dolor sit amet, mel sint conceptam vituperatoribus an. Ad ius habeo utamur eligendi. Eum ad mutat audire aeterno, ei sed virtute reformidans, sonet mentitum conceptam has et. Nihil laudem postea ex eam. Sit tale dictas consulatu ne. Quod aliquid euripidis sed et.', '', '', 9, 'john.doe', '2015-12-31 11:22:47', '2015-01-12', 9, 'john.doe', '2015-12-31 11:22:47', 'Pending', '2015-12-31 11:22:47', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100097, 'testingtesting', 4, 'eee', '1', 'Fisher Scientific', 'ee', 0, 'http://', 2, 2, 0, 'Lorem ipsum dolor sit amet, mel sint conceptam vituperatoribus an. Ad ius habeo utamur eligendi. Eum ad mutat audire aeterno, ei sed virtute reformidans, sonet mentitum conceptam has et. Nihil laudem postea ex eam. Sit tale dictas consulatu ne. Quod aliquid euripidis sed et.', '', '', 1, 'engin.yapici', '2015-12-31 11:24:54', '2015-09-12', 1, 'engin.yapici', '2015-12-31 11:24:54', 'Pending', '2015-12-31 11:24:54', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100098, 'Test1', 13, 'Case of 13', '2', 'Sigma-Aldrich', '12345678', 25, '', 1, 1, 0, 'The standard chundfdfdk odfdsgfsgfsf Lodfdfdfdfdrem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from', '', '', 1, 'engin.yapici', '2015-12-31 11:25:46', '2015-12-16', 1, 'engin.yapici', '2015-12-31 11:25:46', 'Pending', '2015-12-31 11:25:46', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100099, 'dddr', 34, '22', '1', 'Fisher Scientific', 'ddd3', 2, '', 2, 1, 0, '', '', '', 1, 'engin.yapici', '2015-12-31 11:26:36', '2015-08-12', 1, 'engin.yapici', '2015-12-31 11:26:36', 'Pending', '2015-12-31 11:26:36', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100100, 'fghgh', 4434, 'ghdgh', '1', 'Fisher Scientific', 'fgfg', 443, 'http://gfgfg', 1, 2, 0, 'fgfdg', '', '', 9, 'john.doe', '2015-12-31 11:27:05', '2015-09-12', 9, 'john.doe', '2015-12-31 11:27:05', 'Pending', '2015-12-31 11:27:05', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100101, 'fghgh', 4434, 'ghdgh', '1', 'Fisher Scientific', 'fgfg', 443, 'http://gfgfg', 1, 2, 0, 'fgfdg', '', '', 9, 'john.doe', '2015-12-31 11:27:26', '2015-02-12', 9, 'john.doe', '2015-12-31 11:27:26', 'Pending', '2015-12-31 11:27:26', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100102, '1000 uL Filter Tips, Sterile', 2, '960/PK', '2', 'Sigma-Aldrich', '02-707-404PM', 306.22, '', 1, 1, 0, 'None', '', '', 9, 'john.doe', '2015-12-31 11:27:39', '2015-08-12', 9, 'john.doe', '2015-12-31 11:27:39', 'Pending', '2015-12-31 11:27:39', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100103, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://dfd', 1, 1, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', '', '', 9, 'john.doe', '2015-12-31 11:28:27', '2015-12-22', 9, 'john.doe', '2015-12-31 11:28:27', 'Pending', '2015-12-31 11:28:27', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100104, 'Test1', 13, 'Case of 13', '2', 'Sigma-Aldrich', '12345678', 25, 'http://', 1, 1, 0, 'The standard chundfdfdk odfdsgfsgfsf Lodfdfdfdfdrem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from', '', '', 9, 'john.doe', '2015-12-31 11:28:41', '2015-08-12', 9, 'john.doe', '2015-12-31 16:41:33', 'Ordered', '2015-12-31 11:28:41', 9, 'john.doe', 1, '2015-12-31 16:41:33', 9, 'john.doe', 0),
(100105, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://dfd', 1, 1, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', '', '', 9, 'john.doe', '2015-12-31 16:54:53', '2015-08-12', 9, 'john.doe', '2015-12-31 16:54:53', 'Pending', '2015-12-31 16:54:53', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100106, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://dfd', 1, 1, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', '', '', 9, 'john.doe', '2015-12-31 16:55:10', '2015-02-12', 9, 'john.doe', '2015-12-31 16:55:10', 'Pending', '2015-12-31 16:55:10', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100107, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://dfd', 1, 1, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', 'fgfsdg', 'fdgfdg', 1, 'engin.yapici', '2015-12-31 16:57:04', '2016-08-01', 9, 'john.doe', '2015-12-31 16:58:01', 'Delivered', '2015-12-31 16:57:04', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100108, '1000 uL Filter Tips, Sterile', 2, '960/PK', '2', 'Sigma-Aldrich', '02-707-404PM', 306.22, 'http://www.amazon.com/b/ref=nye15_p_gw_d_hero?_encoding=UTF8', 1, 1, 0, 'None', '', '', 9, 'john.doe', '2015-12-31 17:01:22', '2015-12-16', 9, 'john.doe', '2015-12-31 17:02:00', 'Pending', '2015-12-31 17:01:22', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100109, '1000 uL Filter Tips, Sterile', 2, '960/PK', '2', 'Sigma-Aldrich', '02-707-404PM', 306.22, 'http://www.amazon.com/b/ref=nye15_p_gw_d_hero?_encoding=UTF8&amp;node=10481056011&amp;pf_rd_m=ATVPDKIKX0DER&amp;pf_rd_s=desktop-hero-F&amp;pf_rd_r=0H869NZT73BBR7PZ6DJ4&amp;pf_rd_t=36701&amp;pf_rd_p=2363819482&amp;pf_rd_i=desktop', 1, 1, 0, 'None', '', '', 9, 'john.doe', '2015-12-31 17:04:16', '2015-09-12', 9, 'john.doe', '2015-12-31 17:08:49', 'Pending', '2015-12-31 17:04:16', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100110, '1000 uL Filter Tips, Sterile', 2, '960/PK', '2', 'Sigma-Aldrich', '02-707-404PM', 306.22, 'http://www.amazon.com/b/ref=nye15_p_gw_d_hero?_encoding=UTF8&amp;node=10481056011&amp;pf_rd_m=ATVPDKIKX0DER&amp;pf_rd_s=desktop-hero-F&amp;pf_rd_r=0H869NZT73BBR7PZ6DJ4&amp;pf_rd_t=36701&amp;pf_rd_p=2363819482&amp;pf_rd_i=desktop', 1, 1, 0, 'None', '', '', 9, 'john.doe', '2015-12-31 17:09:11', '2015-08-12', 9, 'john.doe', '2015-12-31 17:09:11', 'Pending', '2015-12-31 17:09:11', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100111, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://dfd', 1, 1, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', '', '', 1, 'engin.yapici', '2016-01-03 17:06:15', '2016-01-27', 1, 'engin.yapici', '2016-01-03 17:06:15', 'Pending', '2016-01-03 17:06:15', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100112, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://dfd', 1, 1, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', '', '', 1, 'engin.yapici', '2016-01-03 17:09:36', '2016-01-21', 1, 'engin.yapici', '2016-01-03 17:09:36', 'Pending', '2016-01-03 17:09:36', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100113, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://dfd', 1, 1, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', '', '', 1, 'engin.yapici', '2016-01-03 17:10:11', '2016-01-13', 1, 'engin.yapici', '2016-01-03 17:10:11', 'Pending', '2016-01-03 17:10:11', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100114, 'SATWIPES NW 4x4 70 IPA1', 11, '185/PK1', '4', 'Bio-Rad', '19-170-9511', 248.471, 'http://dfd1', 2, 2, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.1', '1', '1', 1, 'engin.yapici', '2016-01-03 17:10:43', '2016-01-26', 9, 'john.doe', '2016-01-05 14:18:52', 'Processing', '2016-01-03 17:10:43', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100115, 'SATWIPES NW 4x4 70 IPA', 1, '185/PK', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://dfd', 1, 1, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', '', '', 1, 'engin.yapici', '2016-01-03 17:12:13', '2016-01-01', 1, 'engin.yapici', '2016-01-03 17:12:13', 'Pending', '2016-01-03 17:12:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100116, 'SATWIPES NW 4x4 70 IPA', 0, '1', '2', 'Sigma-Aldrich', '19-170-951', 248.47, 'http://dfd', 1, 1, 0, 'Backordered. Available on 20 Nov 2015 from RALEIGH, NC.', '3434', '343', 1, 'engin.yapici', '2016-01-03 17:13:04', '2016-01-19', 9, 'john.doe', '2016-01-05 12:27:06', 'Pending', '2016-01-03 17:13:04', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100117, 'testingtesting', 4, 'eee', '1', 'Fisher Scientific', 'ee', 0, 'http://', 2, 2, 0, 'Lorem ipsum dolor sit amet, mel sint conceptam vituperatoribus an. Ad ius habeo utamur eligendi. Eum ad mutat audire aeterno, ei sed virtute reformidans, sonet mentitum conceptam has et. Nihil laudem postea ex eam. Sit tale dictas consulatu ne. Quod aliquid euripidis sed et.', '', '', 1, 'engin.yapici', '2016-01-03 17:14:13', '2016-01-27', 1, 'engin.yapici', '2016-01-03 17:14:13', 'Pending', '2016-01-03 17:14:13', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100118, 'testingtesting', 4, 'eee', '60', 'test', 'ee', 0, 'http://', 2, 2, 0, 'Lorem ipsum dolor sit amet, mel sint conceptam vituperatoribus an. Ad ius habeo utamur eligendi. Eum ad mutat audire aeterno, ei sed virtute reformidans, sonet mentitum conceptam has et. Nihil laudem postea ex eam. Sit tale dictas consulatu ne. Quod aliquid euripidis sed et.', '', '', 1, 'engin.yapici', '2016-01-03 17:15:07', '2016-05-01', 1, 'engin.yapici', '2016-01-03 17:15:07', 'Pending', '2016-01-03 17:15:07', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100119, 'testingtesting', 4, 'eee', '2', 'Sigma-Aldrich', 'ee', 0, 'http://', 2, 2, 0, 'Lorem ipsum dolor sit amet, mel sint conceptam vituperatoribus an. Ad ius habeo utamur eligendi. Eum ad mutat audire aeterno, ei sed virtute reformidans, sonet mentitum conceptam has et. Nihil laudem postea ex eam. Sit tale dictas consulatu ne. Quod aliquid euripidis sed et.', '', '', 9, 'john.doe', '2016-01-03 17:19:50', '2016-12-01', 9, 'john.doe', '2016-01-03 18:50:02', 'Ordered', '2016-01-03 17:19:50', 9, 'john.doe', 1, '2016-01-03 18:50:02', 9, 'john.doe', 0),
(100120, 'fghgh', 4434, 'ghdgh', '1', 'Fisher Scientific', 'fgfg', 443, 'http://gfgfg', 1, 2, 0, 'fgfdg', '', '', 1, 'engin.yapici', '2016-01-03 17:35:07', '2016-06-01', 1, 'engin.yapici', '2016-01-03 17:35:07', 'Pending', '2016-01-03 17:35:07', 1, 'engin.yapici', 0, '0000-00-00 00:00:00', 0, '', 0),
(100121, 'Testtest', 0, '0', '62', 'test', '02-707-404PM', 306.22, 'http://', 1, 1, 0, 'None', '', '', 1, 'engin.yapici', '2016-01-03 17:35:59', '2016-01-13', 9, 'john.doe', '2016-01-05 12:17:52', 'Ordered', '2016-01-03 17:35:59', 1, 'engin.yapici', 1, '2016-01-05 12:17:52', 9, 'john.doe', 0),
(100122, 'Testtest', 0, '0', '62', 'test', '12345678', 25, 'http://', 1, 1, 0, 'The standard chundfdfdk odfdsgfsgfsf Lodfdfdfdfdrem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from', '', '', 1, 'engin.yapici', '2016-01-03 17:36:38', '2016-01-13', 9, 'john.doe', '2016-01-05 12:18:08', 'Ordered', '2016-01-03 17:36:38', 1, 'engin.yapici', 0, '2016-01-03 18:49:03', 9, 'john.doe', 0),
(100123, 'Test', 0, '0', '5', 'CisBio', 'dgfgf', 0, 'http://cvgfsg', 2, 1, 0, '', '', '', 1, 'engin.yapici', '2016-01-03 18:14:12', '2016-01-18', 9, 'john.doe', '2016-01-05 12:17:25', 'Ordered', '2016-01-03 18:14:12', 1, 'engin.yapici', 0, '2016-01-03 18:46:46', 9, 'john.doe', 0),
(100124, 'Testing', 0, '0', '1', 'Fisher Scientific', '02-707-404PM', 306.22, 'http://www.amazon.com/b/ref=ods_gw_d_h1_dash_offerT?_encoding=UTF8&amp;node=10667898011&amp;pf_rd_m=ATVPDKIKX0DER&amp;pf_rd_s=desktop-hero-kindle-A&amp;pf_rd_r=1Q6AN162CF5SPNZD3S1W&amp;pf_rd_t=36701&amp;pf_rd_p=2376520822&amp;pf_rd_i=desktop', 1, 1, 0, 'None', '', '', 9, 'john.doe', '2016-01-05 08:31:08', '2016-06-01', 9, 'john.doe', '2016-01-05 12:17:36', 'Pending', '2016-01-05 08:31:08', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0),
(100125, 'Test1', 2, '2Test', '5', 'CisBio', 'Test', 0, 'http://Test', 2, 1, 0, 'Test', 'Test', 'Test', 9, 'john.doe', '2016-01-05 12:30:18', '2016-01-21', 9, 'john.doe', '2016-01-05 14:04:21', 'Pending', '2016-01-05 12:30:18', 9, 'john.doe', 0, '0000-00-00 00:00:00', 0, '', 0);

--
-- Triggers `orders`
--
DROP TRIGGER IF EXISTS `after_insert_orders`;
DELIMITER //
CREATE TRIGGER `after_insert_orders` AFTER INSERT ON `orders`
 FOR EACH ROW INSERT INTO audit_trail 
            (`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
        VALUES 
            ("orders", NEW.id, "NEW_ITEM", "NEW_ITEM", NEW.description, NEW.requested_by_id)
//
DELIMITER ;
DROP TRIGGER IF EXISTS `after_update_orders`;
DELIMITER //
CREATE TRIGGER `after_update_orders` AFTER UPDATE ON `orders`
 FOR EACH ROW begin
IF OLD.description != NEW.description THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "description", OLD.description, NEW.description, NEW.last_updated_by_id);
END IF;

IF OLD.quantity != NEW.quantity THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "quantity", OLD.quantity, NEW.quantity, NEW.last_updated_by_id);
END IF;

IF OLD.uom != NEW.uom THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "uom", OLD.uom, NEW.uom, NEW.last_updated_by_id);
END IF;

IF OLD.vendor != NEW.vendor THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "vendor", OLD.vendor, NEW.vendor, NEW.last_updated_by_id);
END IF;

IF OLD.vendor_name != NEW.vendor_name THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "vendor_name", OLD.vendor_name, NEW.vendor_name, NEW.last_updated_by_id);
END IF;

IF OLD.catalog_no != NEW.catalog_no THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "catalog_no", OLD.catalog_no, NEW.catalog_no, NEW.last_updated_by_id);
END IF;

IF OLD.price != NEW.price THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "price", OLD.price, NEW.price, NEW.last_updated_by_id);
END IF;

IF OLD.weblink != NEW.weblink THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "weblink", OLD.weblink, NEW.weblink, NEW.last_updated_by_id);
END IF;

IF OLD.cost_center != NEW.cost_center THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "cost_center", OLD.cost_center, NEW.cost_center, NEW.last_updated_by_id);
END IF;

IF OLD.project != NEW.project THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "project", OLD.project, NEW.project, NEW.last_updated_by_id);
END IF;

IF OLD.comments != NEW.comments THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "comments", OLD.comments, NEW.comments, NEW.last_updated_by_id);
END IF;

IF OLD.vendor_order_no != NEW.vendor_order_no THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "vendor_order_no", OLD.vendor_order_no, NEW.vendor_order_no, NEW.last_updated_by_id);
END IF;

IF OLD.invoice_no != NEW.invoice_no THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "invoice_no", OLD.invoice_no, NEW.invoice_no, NEW.last_updated_by_id);
END IF;

IF OLD.status != NEW.status THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("orders", OLD.id, "status", OLD.status, NEW.status, NEW.last_updated_by_id);
END IF;
end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `number` varchar(200) NOT NULL,
  `date_added` datetime NOT NULL,
  `added_by_user_id` int(11) NOT NULL,
  `added_by_username` varchar(100) NOT NULL,
  `last_updated_date` datetime NOT NULL,
  `last_updated_by_user_id` int(11) NOT NULL,
  `last_updated_by_username` varchar(100) NOT NULL,
  `active` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `number`, `date_added`, `added_by_user_id`, `added_by_username`, `last_updated_date`, `last_updated_by_user_id`, `last_updated_by_username`, `active`) VALUES
(1, 'Project 12', '12345ZXCVB1', '0000-00-00 00:00:00', 1, 'engin.yapici', '2015-12-28 07:31:23', 9, 'john.doe', 1),
(2, 'Project 2ckl', '98765ABVCXf', '0000-00-00 00:00:00', 2, 'john.doe', '2015-12-28 08:02:02', 9, 'john.doe', 1),
(3, 'testdf1', 'test1', '2015-12-28 08:12:31', 9, 'john.doe', '2016-01-05 14:36:39', 9, 'john.doe', 1),
(4, '1', '1', '2016-01-05 14:36:41', 9, 'john.doe', '2016-01-05 14:36:41', 9, 'john.doe', 1);

--
-- Triggers `projects`
--
DROP TRIGGER IF EXISTS `after_insert_projects`;
DELIMITER //
CREATE TRIGGER `after_insert_projects` AFTER INSERT ON `projects`
 FOR EACH ROW INSERT INTO audit_trail 
            (`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
        VALUES 
            ("projects", NEW.id, "NEW_ITEM", "NEW_ITEM", NEW.name, NEW.added_by_user_id)
//
DELIMITER ;
DROP TRIGGER IF EXISTS `after_update_projects`;
DELIMITER //
CREATE TRIGGER `after_update_projects` AFTER UPDATE ON `projects`
 FOR EACH ROW begin
IF OLD.name != NEW.name THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("projects", OLD.id, "name", OLD.name, NEW.name, NEW.last_updated_by_user_id);
END IF;

IF OLD.number != NEW.number THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("projects", OLD.id, "number", OLD.number, NEW.number, NEW.last_updated_by_user_id);
END IF;

IF OLD.active != NEW.active THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("projects", OLD.id, "active", OLD.active, NEW.active, NEW.last_updated_by_user_id);
END IF;
end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(300) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activation` varchar(100) NOT NULL,
  `last_login_date` datetime NOT NULL,
  `account_status` int(11) NOT NULL DEFAULT '0',
  `user_type` int(1) NOT NULL DEFAULT '0',
  `forgot_password` varchar(100) NOT NULL DEFAULT '0',
  `password_reset` int(11) NOT NULL DEFAULT '0',
  `last_updated_date` datetime NOT NULL,
  `last_updated_by_user_id` int(11) NOT NULL,
  `last_updated_by_username` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `phone`, `password`, `registration_date`, `activation`, `last_login_date`, `account_status`, `user_type`, `forgot_password`, `password_reset`, `last_updated_date`, `last_updated_by_user_id`, `last_updated_by_username`) VALUES
(1, 'Engin', 'Yapici', 'engin.yapici', 'engin.yapici@example.com', '1-555-555-555', '$2y$10$Oy1V/pmNd96MdqWvjdPyMuwYyMW3FF6QvVLPcJ1TemaaTX.YFodUG', '2014-11-04 16:45:16', '', '2016-01-03 22:29:47', 1, 0, '1G2z8IZcmNVvASrDiOjRp5U64oXeLBFbqhy7HPWaEQ903TdfwYxklnMJsuCg', 0, '2015-12-31 16:59:07', 9, 'john.doe'),
(9, 'John', 'Doe', 'john.doe', 'john.doe@example.com', '1-111-111-1111', '$2y$10$2TdVIQym8TUWkk1xhtBI5OOA9Z6xftytSAhrM.kcs64If4b5AjG3e', '2015-10-23 20:27:20', '', '2016-01-05 14:36:12', 1, 1, '0', 0, '2015-12-30 22:04:45', 9, 'john.doe'),
(10, '', '', 'dd', 'engin.yapici@gmail.com', '1', '$2y$10$I/aR3Nuel3wMqpPvPf.vJuagFfegGEULPFC9YaPHrAClIL9ictIF2', '2015-12-31 18:47:44', '', '2015-12-31 12:47:44', 1, 2, '0', 0, '2016-01-05 14:35:56', 9, 'john.doe'),
(11, '', '', 'd', 'd@example.com', '', '$2y$10$6wBJIejEnJGz1L2cz8m04OhcLXk36V5hpUG9hzV0fNKgifkqIMmb6', '2015-12-31 18:50:00', '', '2015-12-31 12:50:00', 1, 0, '0', 0, '0000-00-00 00:00:00', 0, ''),
(12, '', '', 'engin.yapici', 'engin.yapic1i@example.com', '', '$2y$10$xxrdZKmxMuzUbbZC9jCIlOzYJ/qADQpf85cbO8aRJv7Cwr3c/I6Ea', '2015-12-31 18:52:19', '', '2015-12-31 12:52:19', 1, 0, '0', 0, '2016-01-03 16:43:32', 9, 'john.doe'),
(13, '', '', 'engin.yapici', 'engin.yapicei@example.com', '', '$2y$10$cho5xb/3avY/uWb//YgmpeUv8CJcQFFtaL3FONdCEwENo2iZhDHYi', '2015-12-31 19:15:47', 'xrLBHnQfeZS3jW0zpGimqKAY7DckJbyguIR2O1C8MsdTVNw9h6FaPv4ltXUE', '2015-12-31 13:15:46', 1, 0, '0', 0, '2016-01-03 16:40:58', 9, 'john.doe'),
(14, '', '', 'engin.yapici', 'engin.yapdici@hospira.com', '', '$2y$10$kfi8PnkXOcNoTgaort8OfeFwKnp/t7y/q36oFBw4poVEWb0liD0DO', '2015-12-31 20:43:44', 'cn2isP5XAOUqG0dIpDfxN4Er7W1a9B6zYJwLCvlSZhytKo3ubMVkeQ8TmgjH', '2015-12-31 14:43:44', 1, 0, '0', 0, '0000-00-00 00:00:00', 0, ''),
(15, '', '', 'engin.yapici', 'd', '', '$2y$10$mzACYRb4Rg9/BJT.Uwep4eQi5FCFylbk.eCEcd4nrtYifnv2Zj0oC', '2015-12-31 21:16:02', 'Mz3CSph9m7iEGNuAQjaVOKB84oITrHqknyF5c06fJUdvsYb2ZwXxelWLgDt1', '2015-12-31 15:16:02', 1, 0, '0', 0, '0000-00-00 00:00:00', 0, ''),
(16, '', '', 'engin.yapici', 'g', '', '$2y$10$BO.hiwq/Oqk.zbL0uNVU5OhesUxo/vRTqjMpBZ.kB4IuJEEfrE0iG', '2015-12-31 21:19:42', 'dr0bRBSHWMLXxZlQin7cD1PsjGu5K2E9hpNFVAUzt6vmeIT8fJq4C3aYywko', '2015-12-31 15:19:42', 1, 0, '0', 0, '0000-00-00 00:00:00', 0, ''),
(17, '', '', 'engin.yapici', 'engin.yapici@hospira.com', '', '$2y$10$LKYBNq4jmLiG8gCL52l5D.exRtZyAuofHN/k/f.34Vd10LL2RzlAS', '2015-12-31 21:24:32', '5QAZyT3SkcJKsWBqNOGadV0gIL2vf8uX7z9ploimnw4D1MHbeRYxhPEUjCrF', '2015-12-31 15:24:32', 1, 1, '0', 0, '0000-00-00 00:00:00', 0, '');

--
-- Triggers `users`
--
DROP TRIGGER IF EXISTS `after_insert_users`;
DELIMITER //
CREATE TRIGGER `after_insert_users` AFTER INSERT ON `users`
 FOR EACH ROW INSERT INTO audit_trail 
            (`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
        VALUES 
            ("users", NEW.id, "NEW_ITEM", "NEW_ITEM", NEW.username, NEW.id)
//
DELIMITER ;
DROP TRIGGER IF EXISTS `after_update_users`;
DELIMITER //
CREATE TRIGGER `after_update_users` AFTER UPDATE ON `users`
 FOR EACH ROW begin
IF OLD.phone != NEW.phone THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("users", OLD.id, "phone", OLD.phone, NEW.phone, NEW.last_updated_by_user_id);
END IF;

IF OLD.account_status != NEW.account_status THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("users", OLD.id, "account_status", OLD.account_status, NEW.account_status, NEW.last_updated_by_user_id);
END IF;

IF OLD.user_type != NEW.user_type THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("users", OLD.id, "user_type", OLD.user_type, NEW.user_type, NEW.last_updated_by_user_id);
END IF;

IF OLD.last_login_date != NEW.last_login_date THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("users", OLD.id, "last_login_date", OLD.last_login_date, NEW.last_login_date, NEW.id);
END IF;

IF OLD.password_reset != NEW.password_reset THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("users", OLD.id, "password_reset", OLD.password_reset, NEW.password_reset, NEW.id);
END IF;
end
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE IF NOT EXISTS `vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `contact_person` varchar(200) NOT NULL,
  `account_number` varchar(200) NOT NULL,
  `approved` int(1) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL,
  `added_by_user_id` int(11) NOT NULL,
  `added_by_username` varchar(100) NOT NULL,
  `last_updated_by_user_id` int(11) NOT NULL,
  `last_updated_by_username` varchar(100) NOT NULL,
  `last_updated_date` datetime NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  `deleted_date` datetime NOT NULL,
  `deleted_by_user_id` int(11) NOT NULL,
  `deleted_by_username` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `name`, `phone`, `address`, `website`, `contact_person`, `account_number`, `approved`, `date_added`, `added_by_user_id`, `added_by_username`, `last_updated_by_user_id`, `last_updated_by_username`, `last_updated_date`, `deleted`, `deleted_date`, `deleted_by_user_id`, `deleted_by_username`) VALUES
(1, 'Fisher Scientific', '1-800-766-7000', '4500 Turnberry Dr, Hanover Park, IL 60133', 'https://www.fishersci.com/', 'Jane Doe', 'F123456789', 1, '0000-00-00 00:00:00', 0, '', 9, 'john.doe', '2015-12-24 12:25:04', 0, '2015-12-27 19:54:25', 9, 'john.doe'),
(2, 'Sigma-Aldrich', '1-800-325-3010', '6000 N Teutonia Ave, Milwaukee, WI 53209', 'http://www.sigmaaldrich.com/', '', 'S987654321', 1, '0000-00-00 00:00:00', 0, '', 9, 'john.doe', '2015-12-19 21:51:28', 0, '2015-12-27 19:54:25', 9, 'john.doe'),
(3, 'VWR', '1-800-932-5000', '800 East Fabyan Parkway, Batavia, IL 60510', 'https://us.vwr.com/', '', 'V1234567890', 1, '0000-00-00 00:00:00', 0, '', 9, 'john.doe', '2015-12-19 21:51:28', 0, '0000-00-00 00:00:00', 0, ''),
(4, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', 'B9876543210', 1, '2015-12-17 07:44:53', 1, 'engin.yapici', 9, 'john.doe', '2015-12-24 12:24:52', 0, '0000-00-00 00:00:00', 0, ''),
(5, 'CisBio', '1-888-963-4567', '135 South Road Bedford, MA 01730, USA', 'http://www.cisbio.com/', '', 'C1234567890', 1, '2015-12-17 07:46:45', 1, 'engin.yapici', 9, 'john.doe', '2015-12-31 16:58:29', 0, '0000-00-00 00:00:00', 0, ''),
(6, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 07:50:25', 1, 'engin.yapici', 9, 'john.doe', '2015-12-19 22:07:20', 1, '2015-12-20 20:41:47', 9, 'john.doe'),
(7, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 07:50:50', 1, 'engin.yapici', 9, 'john.doe', '2015-12-19 21:51:28', 1, '2015-12-20 20:41:40', 9, 'john.doe'),
(8, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 07:52:57', 1, 'engin.yapici', 1, '0', '2015-12-17 07:52:57', 1, '2015-12-20 20:41:35', 9, 'john.doe'),
(9, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 07:53:59', 1, 'engin.yapici', 1, '0', '2015-12-17 07:53:59', 1, '2015-12-20 20:41:33', 9, 'john.doe'),
(10, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 07:57:02', 1, 'engin.yapici', 1, '0', '2015-12-17 07:57:02', 1, '2015-12-20 20:41:30', 9, 'john.doe'),
(11, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 07:58:47', 1, 'engin.yapici', 1, '0', '2015-12-17 07:58:47', 1, '2015-12-20 20:39:39', 9, 'john.doe'),
(12, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 07:59:46', 1, 'engin.yapici', 1, '0', '2015-12-17 07:59:46', 1, '2015-12-20 20:38:01', 9, 'john.doe'),
(13, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 08:00:30', 1, 'engin.yapici', 1, '0', '2015-12-17 08:00:30', 1, '2015-12-20 20:37:29', 9, 'john.doe'),
(14, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 08:00:56', 1, 'engin.yapici', 1, '0', '2015-12-17 08:00:56', 1, '2015-12-20 20:37:11', 9, 'john.doe'),
(15, 'Bio-Rad', '1-510-741-1000', '2000 Alfred Nobel Drive Hercules, California 94547 USA', 'http://www.bio-rad.com', '', '', 0, '2015-12-17 08:02:38', 1, 'engin.yapici', 1, '0', '2015-12-17 08:02:38', 1, '2015-12-20 20:37:05', 9, 'john.doe'),
(16, 'Name', 'Phone', 'Address', 'Website', 'Contact Person', '', 1, '2015-12-20 20:12:50', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:12:50', 1, '2015-12-20 20:34:52', 9, 'john.doe'),
(17, 'Name', 'Phone', 'Address', 'Website', 'Contact Person', '', 1, '2015-12-20 20:13:53', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:13:53', 1, '2015-12-20 20:34:06', 9, 'john.doe'),
(18, 'Test', 'TEST', '', '', '', '', 1, '2015-12-20 20:38:31', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:38:31', 1, '2015-12-20 20:38:32', 9, 'john.doe'),
(19, 'adfgds', 'dsgfdg', '', '', '', '', 1, '2015-12-20 20:39:24', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:39:24', 1, '2015-12-20 20:39:30', 9, 'john.doe'),
(20, 'dfds', 'fdsgf', '', '', '', '', 1, '2015-12-20 20:41:19', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:41:19', 1, '2015-12-20 20:41:26', 9, 'john.doe'),
(21, 'gfd', 'hfghgf', 'fghgfh', 'gfh', 'ghg', '', 1, '2015-12-20 20:42:11', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:42:11', 1, '2015-12-20 20:42:13', 9, 'john.doe'),
(22, 'sdgf', 'sgfd', 'gdfdfdf', 'http://gdfg', 'gdf', '', 1, '2015-12-20 20:43:40', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:43:40', 1, '2015-12-20 20:43:43', 9, 'john.doe'),
(23, 'ad', 'fdsg', 'gfgfg', 'http://fsgfd', 'fgfg', '', 1, '2015-12-20 20:47:06', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:06', 1, '2015-12-20 20:47:07', 9, 'john.doe'),
(24, 'dfdsg', 'fsg', 'fgfg', 'http://fdg', 'fgfg', '', 1, '2015-12-20 20:47:27', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:27', 1, '2015-12-20 20:47:28', 9, 'john.doe'),
(25, 'dfdsg', 'fsg', 'fgfg', 'http://fdg', 'fgfg', '', 1, '2015-12-20 20:47:31', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:31', 1, '2015-12-20 20:47:37', 9, 'john.doe'),
(26, 'dfdsg', 'fsg', 'fgfg', 'http://fdg', 'fgfg', '', 1, '2015-12-20 20:47:32', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:32', 1, '2015-12-20 20:47:38', 9, 'john.doe'),
(27, 'dfdsg', 'fsg', 'fgfg', 'http://fdg', 'fgfg', '', 1, '2015-12-20 20:47:33', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:33', 1, '2015-12-20 20:47:39', 9, 'john.doe'),
(28, 'dfdsg', 'fsg', 'fgfg', 'http://fdg', 'fgfg', '', 1, '2015-12-20 20:47:34', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:34', 1, '2015-12-20 20:47:39', 9, 'john.doe'),
(29, 'dfdsg', 'fsg', 'fgfg', 'http://fdg', 'fgfg', '', 1, '2015-12-20 20:47:35', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:35', 1, '2015-12-20 20:47:39', 9, 'john.doe'),
(30, 'dfdsg', 'fsg', 'fgfg', 'http://fdg', 'fgfg', '', 1, '2015-12-20 20:47:35', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:35', 1, '2015-12-20 20:47:40', 9, 'john.doe'),
(31, 'dfdsg', 'fsg', 'fgfg', 'http://fdg', 'fgfg', '', 1, '2015-12-20 20:47:36', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:36', 1, '2015-12-20 20:47:40', 9, 'john.doe'),
(32, 'dfdsg', 'fsg', 'fgfg', 'http://fdg', 'fgfg', '', 1, '2015-12-20 20:47:43', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:47:43', 1, '2015-12-20 20:49:29', 9, 'john.doe'),
(33, 'sdg', 'fs', '', '', '', '', 1, '2015-12-20 20:48:52', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:48:52', 1, '2015-12-20 20:49:28', 9, 'john.doe'),
(34, 'sdg', 'fsg', 'fdgfg', 'http://fdg', 'fgf', '', 1, '2015-12-20 20:48:56', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:48:56', 1, '2015-12-20 20:49:27', 9, 'john.doe'),
(35, '&lt;script&gt;alert(''dfd'');&lt;/script&gt;', '&lt;script&gt;alert(''dfd'');&lt;/script&gt;', '&lt;script&gt;alert(''dfd'');&lt;/script&gt;', 'http://&lt;script&gt;alert(''dfd'');&lt;/script&gt;', '&lt;script&gt;alert(''dfd'');&lt;/script&gt;', '', 1, '2015-12-20 20:49:22', 9, 'john.doe', 9, 'john.doe', '2015-12-20 20:49:22', 1, '2015-12-20 20:49:25', 9, 'john.doe'),
(36, 'dsfds', 'dfdf', '', '', '', '', 1, '2015-12-21 08:31:01', 1, 'engin.yapici', 1, 'engin.yapici', '2015-12-21 08:31:01', 1, '2015-12-21 08:31:22', 1, 'engin.yapici'),
(37, 'Test', '1-312-555-55555', '', '', '', '', 1, '2015-12-21 13:11:44', 1, 'engin.yapici', 9, 'john.doe', '2015-12-21 13:21:18', 1, '2015-12-21 13:21:40', 9, 'john.doe'),
(38, 'Test', '1-312-555-55555', '', '', '', '', 0, '2015-12-21 13:12:18', 1, 'engin.yapici', 1, 'engin.yapici', '2015-12-21 13:12:18', 1, '2015-12-21 13:21:39', 9, 'john.doe'),
(39, 'dfg', 'testffgfg', 'fgfgf', 'fgfgf', 'ddfdf', '', 1, '2015-12-21 13:20:08', 9, 'john.doe', 9, 'john.doe', '2015-12-21 13:20:31', 1, '2015-12-21 13:21:37', 9, 'john.doe'),
(40, 'gtrt', 'rtr', 'rtr', 'http://tr', 'trt', '', 1, '2015-12-21 14:05:55', 9, 'john.doe', 9, 'john.doe', '2015-12-21 14:05:55', 1, '2015-12-21 14:05:56', 9, 'john.doe'),
(41, 'dgf', 'gfg', 'fgfg', 'http://fg', 'fgf', '', 1, '2015-12-23 11:21:13', 1, 'engin.yapici', 1, 'engin.yapici', '2015-12-23 11:21:13', 1, '2015-12-23 11:24:17', 9, 'john.doe'),
(42, 'dsg', 'fsgf', 'gfgfjjggff', 'http://dgf', 'gf', '', 1, '2015-12-23 11:44:08', 9, 'john.doe', 9, 'john.doe', '2015-12-23 12:13:53', 1, '2015-12-23 17:14:09', 9, 'john.doe'),
(43, 'Test', 'Test', 'test', 'test.com', '', '', 0, '2015-12-23 18:14:44', 9, 'john.doe', 9, 'john.doe', '2015-12-23 18:14:44', 1, '2015-12-24 12:25:45', 9, 'john.doe'),
(44, 'dsg', 'fsdg', 'fdgfg', 'http://fsdg', 'fgfg', 'fg', 1, '2015-12-24 12:30:05', 9, 'john.doe', 9, 'john.doe', '2015-12-24 12:30:05', 1, '2015-12-24 12:30:19', 9, 'john.doe'),
(45, 'fg', 'fdg', 'gfgf', 'http://f', 'gfg', '', 1, '2015-12-24 12:30:09', 9, 'john.doe', 9, 'john.doe', '2015-12-24 12:30:09', 1, '2015-12-24 12:30:19', 9, 'john.doe'),
(46, 'dgfg', 'dfdf', 'fhgfhfg', 'fgfg', 'hfd', 'bfdbhfdhbf', 1, '2015-12-24 12:30:15', 9, 'john.doe', 9, 'john.doe', '2015-12-24 12:31:02', 1, '2015-12-24 12:32:04', 9, 'john.doe'),
(47, 're', 'tehyetehy', '', '', '', 'Account No', 1, '2015-12-24 12:51:45', 9, 'john.doe', 9, 'john.doe', '2015-12-24 12:51:45', 1, '2015-12-24 12:51:46', 9, 'john.doe'),
(48, 'erhy', 'et', 'heth', 'http://hyte', '', '', 1, '2015-12-24 12:51:50', 9, 'john.doe', 9, 'john.doe', '2015-12-24 12:51:50', 1, '2015-12-24 12:52:00', 9, 'john.doe'),
(49, 'ehg', 'eth', 'tehte', '', '', 'Account No', 1, '2015-12-24 12:51:56', 9, 'john.doe', 9, 'john.doe', '2015-12-24 12:51:56', 1, '2015-12-24 12:52:00', 9, 'john.doe'),
(50, 'yth', 'eth', 'th', 'http://teh', 'thtr', 'tehy', 1, '2015-12-24 12:52:07', 9, 'john.doe', 9, 'john.doe', '2015-12-24 12:52:07', 1, '2015-12-24 12:52:09', 9, 'john.doe'),
(51, 'fdg', 'dg', 'vbvvnfbn', 'http://dfgdf', 'bnb', 'Account No', 1, '2015-12-27 19:46:36', 9, 'john.doe', 9, 'john.doe', '2015-12-27 19:48:06', 1, '2015-12-28 07:24:03', 9, 'john.doe'),
(52, 'b', 'dnb', '', 'http://n', '', 'Account No', 1, '2015-12-27 19:48:09', 9, 'john.doe', 9, 'john.doe', '2015-12-27 19:48:09', 1, '2015-12-29 15:28:32', 9, 'john.doe'),
(53, 'dsfg', 'sg', 'df', 'http://fsgfsg', 'dfd', 'sds', 1, '2015-12-27 19:51:12', 9, 'john.doe', 9, 'john.doe', '2015-12-27 19:51:17', 1, '2015-12-29 15:28:33', 9, 'john.doe'),
(54, 'dwfd', 'wgfew', '', 'http://g', '', '', 0, '2015-12-28 07:47:54', 9, 'john.doe', 9, 'john.doe', '2015-12-29 15:28:35', 1, '2015-12-30 12:28:44', 9, 'john.doe'),
(55, 'sfdg', 'fsg', 'fdgfg', 'http://fg', 'g', 'fgfg', 0, '2015-12-28 07:47:59', 9, 'john.doe', 9, 'john.doe', '2015-12-29 15:28:35', 1, '2015-12-29 16:27:56', 9, 'john.doe'),
(56, 'dgfdsgfgfgfgfg', 'gfdsgfd', 'fgfgfgfgf', 'aaaaaa', '', '', 0, '2015-12-29 15:29:04', 9, 'john.doe', 9, 'john.doe', '2015-12-29 16:23:26', 1, '2015-12-30 12:30:07', 9, 'john.doe'),
(57, '', '', '', '', '', '', 1, '2015-12-30 10:23:25', 9, 'john.doe', 9, 'john.doe', '2015-12-30 10:23:59', 1, '2015-12-30 10:24:06', 9, 'john.doe'),
(58, 'fg', 'fg', '', 'http://fg', '', '', 0, '2015-12-30 22:13:39', 9, 'john.doe', 9, 'john.doe', '2015-12-30 22:13:43', 1, '2015-12-30 22:13:45', 9, 'john.doe'),
(59, 'fgfd', 'gfg', '', '', '', '', 1, '2015-12-31 16:58:23', 9, 'john.doe', 9, 'john.doe', '2015-12-31 16:58:23', 1, '2015-12-31 16:58:24', 9, 'john.doe'),
(60, 'test', 'test', 'test', 'tes', '', 'test1', 0, '2016-01-03 17:15:07', 1, 'engin.yapici', 9, 'john.doe', '2016-01-04 07:55:48', 0, '0000-00-00 00:00:00', 0, ''),
(61, 'test', 'test', 'test', 'test', '', 'test2', 0, '2016-01-03 17:35:59', 1, 'engin.yapici', 9, 'john.doe', '2016-01-04 07:55:50', 0, '0000-00-00 00:00:00', 0, ''),
(62, 'test', 'test', 'test', '', '', 'test3', 0, '2016-01-03 17:36:38', 1, 'engin.yapici', 9, 'john.doe', '2016-01-05 14:32:26', 0, '0000-00-00 00:00:00', 0, ''),
(63, 'df1', 'sdfg1', '1', '1', '1', '', 0, '2016-01-05 14:30:52', 9, 'john.doe', 9, 'john.doe', '2016-01-05 14:31:02', 1, '2016-01-05 14:31:03', 9, 'john.doe');

--
-- Triggers `vendors`
--
DROP TRIGGER IF EXISTS `after_insert_vendors`;
DELIMITER //
CREATE TRIGGER `after_insert_vendors` AFTER INSERT ON `vendors`
 FOR EACH ROW INSERT INTO audit_trail 
            (`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
        VALUES 
            ("vendors", NEW.id, "NEW_ITEM", "NEW_ITEM", NEW.name, NEW.added_by_user_id)
//
DELIMITER ;
DROP TRIGGER IF EXISTS `after_update_vendors`;
DELIMITER //
CREATE TRIGGER `after_update_vendors` AFTER UPDATE ON `vendors`
 FOR EACH ROW begin
IF OLD.name != NEW.name THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("vendors", OLD.id, "name", OLD.name, NEW.name, NEW.last_updated_by_user_id);
END IF;

IF OLD.phone != NEW.phone THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("vendors", OLD.id, "phone", OLD.phone, NEW.phone, NEW.last_updated_by_user_id);
END IF;

IF OLD.address != NEW.address THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("vendors", OLD.id, "address", OLD.address, NEW.address, NEW.last_updated_by_user_id);
END IF;

IF OLD.website != NEW.website THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("vendors", OLD.id, "website", OLD.website, NEW.website, NEW.last_updated_by_user_id);
END IF;

IF OLD.contact_person != NEW.contact_person THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("vendors", OLD.id, "contact_person", OLD.contact_person, NEW.contact_person, NEW.last_updated_by_user_id);
END IF;

IF OLD.account_number != NEW.account_number THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("vendors", OLD.id, "account_number", OLD.account_number, NEW.account_number, NEW.last_updated_by_user_id);
END IF;

IF OLD.approved != NEW.approved THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("vendors", OLD.id, "approved", OLD.approved, NEW.approved, NEW.last_updated_by_user_id);
END IF;

IF OLD.deleted != NEW.deleted THEN
  INSERT INTO audit_trail 
  		(`changed_table`, `changed_item_id`, `changed_field_name`, `old_value`, `new_value`, `user_id`) 
  VALUES
        ("vendors", OLD.id, "deleted", OLD.deleted, NEW.deleted, NEW.deleted_by_user_id);
END IF;
end
//
DELIMITER ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
