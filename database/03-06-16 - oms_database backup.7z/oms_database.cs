using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Oms_database
{
    #region Audit_trail
    public class Audit_trail
    {
        #region Member Variables
        protected int _id;
        protected string _changed_table;
        protected int _changed_item_id;
        protected string _changed_field_name;
        protected string _old_value;
        protected string _new_value;
        protected unknown _date;
        protected int _user_id;
        #endregion
        #region Constructors
        public Audit_trail() { }
        public Audit_trail(string changed_table, int changed_item_id, string changed_field_name, string old_value, string new_value, unknown date, int user_id)
        {
            this._changed_table=changed_table;
            this._changed_item_id=changed_item_id;
            this._changed_field_name=changed_field_name;
            this._old_value=old_value;
            this._new_value=new_value;
            this._date=date;
            this._user_id=user_id;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Changed_table
        {
            get {return _changed_table;}
            set {_changed_table=value;}
        }
        public virtual int Changed_item_id
        {
            get {return _changed_item_id;}
            set {_changed_item_id=value;}
        }
        public virtual string Changed_field_name
        {
            get {return _changed_field_name;}
            set {_changed_field_name=value;}
        }
        public virtual string Old_value
        {
            get {return _old_value;}
            set {_old_value=value;}
        }
        public virtual string New_value
        {
            get {return _new_value;}
            set {_new_value=value;}
        }
        public virtual unknown Date
        {
            get {return _date;}
            set {_date=value;}
        }
        public virtual int User_id
        {
            get {return _user_id;}
            set {_user_id=value;}
        }
        #endregion
    }
    #endregion
}using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Oms_database
{
    #region Cost_centers
    public class Cost_centers
    {
        #region Member Variables
        protected int _id;
        protected string _name;
        protected DateTime _date_added;
        protected int _added_by_user_id;
        protected string _added_by_username;
        protected DateTime _last_updated_date;
        protected int _last_updated_by_user_id;
        protected string _last_updated_by_username;
        protected int _active;
        #endregion
        #region Constructors
        public Cost_centers() { }
        public Cost_centers(string name, DateTime date_added, int added_by_user_id, string added_by_username, DateTime last_updated_date, int last_updated_by_user_id, string last_updated_by_username, int active)
        {
            this._name=name;
            this._date_added=date_added;
            this._added_by_user_id=added_by_user_id;
            this._added_by_username=added_by_username;
            this._last_updated_date=last_updated_date;
            this._last_updated_by_user_id=last_updated_by_user_id;
            this._last_updated_by_username=last_updated_by_username;
            this._active=active;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Name
        {
            get {return _name;}
            set {_name=value;}
        }
        public virtual DateTime Date_added
        {
            get {return _date_added;}
            set {_date_added=value;}
        }
        public virtual int Added_by_user_id
        {
            get {return _added_by_user_id;}
            set {_added_by_user_id=value;}
        }
        public virtual string Added_by_username
        {
            get {return _added_by_username;}
            set {_added_by_username=value;}
        }
        public virtual DateTime Last_updated_date
        {
            get {return _last_updated_date;}
            set {_last_updated_date=value;}
        }
        public virtual int Last_updated_by_user_id
        {
            get {return _last_updated_by_user_id;}
            set {_last_updated_by_user_id=value;}
        }
        public virtual string Last_updated_by_username
        {
            get {return _last_updated_by_username;}
            set {_last_updated_by_username=value;}
        }
        public virtual int Active
        {
            get {return _active;}
            set {_active=value;}
        }
        #endregion
    }
    #endregion
}using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Oms_database
{
    #region Orders
    public class Orders
    {
        #region Member Variables
        protected int _id;
        protected string _description;
        protected int _quantity;
        protected string _uom;
        protected string _vendor;
        protected string _vendor_name;
        protected string _catalog_no;
        protected unknown _price;
        protected string _weblink;
        protected int _cost_center;
        protected int _project;
        protected int _account_id;
        protected string _comments;
        protected string _sds;
        protected string _vendor_order_no;
        protected string _invoice_no;
        protected int _requested_by_id;
        protected string _requested_by_username;
        protected DateTime _requested_datetime;
        protected unknown _item_needed_by_date;
        protected int _last_updated_by_id;
        protected string _last_updated_by_username;
        protected DateTime _last_updated_datetime;
        protected string _status;
        protected DateTime _status_updated_date;
        protected int _status_updated_by_user_id;
        protected string _status_updated_by_username;
        protected int _ordered;
        protected DateTime _ordered_date;
        protected int _ordered_by_user_id;
        protected string _ordered_by_username;
        protected int _delivered;
        protected DateTime _delivered_date;
        protected int _delivered_by_user_id;
        protected string _delivered_by_username;
        protected int _deleted;
        #endregion
        #region Constructors
        public Orders() { }
        public Orders(string description, int quantity, string uom, string vendor, string vendor_name, string catalog_no, unknown price, string weblink, int cost_center, int project, int account_id, string comments, string sds, string vendor_order_no, string invoice_no, int requested_by_id, string requested_by_username, DateTime requested_datetime, unknown item_needed_by_date, int last_updated_by_id, string last_updated_by_username, DateTime last_updated_datetime, string status, DateTime status_updated_date, int status_updated_by_user_id, string status_updated_by_username, int ordered, DateTime ordered_date, int ordered_by_user_id, string ordered_by_username, int delivered, DateTime delivered_date, int delivered_by_user_id, string delivered_by_username, int deleted)
        {
            this._description=description;
            this._quantity=quantity;
            this._uom=uom;
            this._vendor=vendor;
            this._vendor_name=vendor_name;
            this._catalog_no=catalog_no;
            this._price=price;
            this._weblink=weblink;
            this._cost_center=cost_center;
            this._project=project;
            this._account_id=account_id;
            this._comments=comments;
            this._sds=sds;
            this._vendor_order_no=vendor_order_no;
            this._invoice_no=invoice_no;
            this._requested_by_id=requested_by_id;
            this._requested_by_username=requested_by_username;
            this._requested_datetime=requested_datetime;
            this._item_needed_by_date=item_needed_by_date;
            this._last_updated_by_id=last_updated_by_id;
            this._last_updated_by_username=last_updated_by_username;
            this._last_updated_datetime=last_updated_datetime;
            this._status=status;
            this._status_updated_date=status_updated_date;
            this._status_updated_by_user_id=status_updated_by_user_id;
            this._status_updated_by_username=status_updated_by_username;
            this._ordered=ordered;
            this._ordered_date=ordered_date;
            this._ordered_by_user_id=ordered_by_user_id;
            this._ordered_by_username=ordered_by_username;
            this._delivered=delivered;
            this._delivered_date=delivered_date;
            this._delivered_by_user_id=delivered_by_user_id;
            this._delivered_by_username=delivered_by_username;
            this._deleted=deleted;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Description
        {
            get {return _description;}
            set {_description=value;}
        }
        public virtual int Quantity
        {
            get {return _quantity;}
            set {_quantity=value;}
        }
        public virtual string Uom
        {
            get {return _uom;}
            set {_uom=value;}
        }
        public virtual string Vendor
        {
            get {return _vendor;}
            set {_vendor=value;}
        }
        public virtual string Vendor_name
        {
            get {return _vendor_name;}
            set {_vendor_name=value;}
        }
        public virtual string Catalog_no
        {
            get {return _catalog_no;}
            set {_catalog_no=value;}
        }
        public virtual unknown Price
        {
            get {return _price;}
            set {_price=value;}
        }
        public virtual string Weblink
        {
            get {return _weblink;}
            set {_weblink=value;}
        }
        public virtual int Cost_center
        {
            get {return _cost_center;}
            set {_cost_center=value;}
        }
        public virtual int Project
        {
            get {return _project;}
            set {_project=value;}
        }
        public virtual int Account_id
        {
            get {return _account_id;}
            set {_account_id=value;}
        }
        public virtual string Comments
        {
            get {return _comments;}
            set {_comments=value;}
        }
        public virtual string Sds
        {
            get {return _sds;}
            set {_sds=value;}
        }
        public virtual string Vendor_order_no
        {
            get {return _vendor_order_no;}
            set {_vendor_order_no=value;}
        }
        public virtual string Invoice_no
        {
            get {return _invoice_no;}
            set {_invoice_no=value;}
        }
        public virtual int Requested_by_id
        {
            get {return _requested_by_id;}
            set {_requested_by_id=value;}
        }
        public virtual string Requested_by_username
        {
            get {return _requested_by_username;}
            set {_requested_by_username=value;}
        }
        public virtual DateTime Requested_datetime
        {
            get {return _requested_datetime;}
            set {_requested_datetime=value;}
        }
        public virtual unknown Item_needed_by_date
        {
            get {return _item_needed_by_date;}
            set {_item_needed_by_date=value;}
        }
        public virtual int Last_updated_by_id
        {
            get {return _last_updated_by_id;}
            set {_last_updated_by_id=value;}
        }
        public virtual string Last_updated_by_username
        {
            get {return _last_updated_by_username;}
            set {_last_updated_by_username=value;}
        }
        public virtual DateTime Last_updated_datetime
        {
            get {return _last_updated_datetime;}
            set {_last_updated_datetime=value;}
        }
        public virtual string Status
        {
            get {return _status;}
            set {_status=value;}
        }
        public virtual DateTime Status_updated_date
        {
            get {return _status_updated_date;}
            set {_status_updated_date=value;}
        }
        public virtual int Status_updated_by_user_id
        {
            get {return _status_updated_by_user_id;}
            set {_status_updated_by_user_id=value;}
        }
        public virtual string Status_updated_by_username
        {
            get {return _status_updated_by_username;}
            set {_status_updated_by_username=value;}
        }
        public virtual int Ordered
        {
            get {return _ordered;}
            set {_ordered=value;}
        }
        public virtual DateTime Ordered_date
        {
            get {return _ordered_date;}
            set {_ordered_date=value;}
        }
        public virtual int Ordered_by_user_id
        {
            get {return _ordered_by_user_id;}
            set {_ordered_by_user_id=value;}
        }
        public virtual string Ordered_by_username
        {
            get {return _ordered_by_username;}
            set {_ordered_by_username=value;}
        }
        public virtual int Delivered
        {
            get {return _delivered;}
            set {_delivered=value;}
        }
        public virtual DateTime Delivered_date
        {
            get {return _delivered_date;}
            set {_delivered_date=value;}
        }
        public virtual int Delivered_by_user_id
        {
            get {return _delivered_by_user_id;}
            set {_delivered_by_user_id=value;}
        }
        public virtual string Delivered_by_username
        {
            get {return _delivered_by_username;}
            set {_delivered_by_username=value;}
        }
        public virtual int Deleted
        {
            get {return _deleted;}
            set {_deleted=value;}
        }
        #endregion
    }
    #endregion
}using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Oms_database
{
    #region Projects
    public class Projects
    {
        #region Member Variables
        protected int _id;
        protected string _name;
        protected string _number;
        protected DateTime _date_added;
        protected int _added_by_user_id;
        protected string _added_by_username;
        protected DateTime _last_updated_date;
        protected int _last_updated_by_user_id;
        protected string _last_updated_by_username;
        protected int _active;
        #endregion
        #region Constructors
        public Projects() { }
        public Projects(string name, string number, DateTime date_added, int added_by_user_id, string added_by_username, DateTime last_updated_date, int last_updated_by_user_id, string last_updated_by_username, int active)
        {
            this._name=name;
            this._number=number;
            this._date_added=date_added;
            this._added_by_user_id=added_by_user_id;
            this._added_by_username=added_by_username;
            this._last_updated_date=last_updated_date;
            this._last_updated_by_user_id=last_updated_by_user_id;
            this._last_updated_by_username=last_updated_by_username;
            this._active=active;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Name
        {
            get {return _name;}
            set {_name=value;}
        }
        public virtual string Number
        {
            get {return _number;}
            set {_number=value;}
        }
        public virtual DateTime Date_added
        {
            get {return _date_added;}
            set {_date_added=value;}
        }
        public virtual int Added_by_user_id
        {
            get {return _added_by_user_id;}
            set {_added_by_user_id=value;}
        }
        public virtual string Added_by_username
        {
            get {return _added_by_username;}
            set {_added_by_username=value;}
        }
        public virtual DateTime Last_updated_date
        {
            get {return _last_updated_date;}
            set {_last_updated_date=value;}
        }
        public virtual int Last_updated_by_user_id
        {
            get {return _last_updated_by_user_id;}
            set {_last_updated_by_user_id=value;}
        }
        public virtual string Last_updated_by_username
        {
            get {return _last_updated_by_username;}
            set {_last_updated_by_username=value;}
        }
        public virtual int Active
        {
            get {return _active;}
            set {_active=value;}
        }
        #endregion
    }
    #endregion
}using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Oms_database
{
    #region Users
    public class Users
    {
        #region Member Variables
        protected int _id;
        protected string _first_name;
        protected string _last_name;
        protected string _username;
        protected string _email;
        protected string _phone;
        protected string _password;
        protected unknown _registration_date;
        protected string _activation;
        protected DateTime _last_login_date;
        protected int _account_status;
        protected int _user_type;
        protected string _forgot_password;
        protected int _password_reset;
        protected DateTime _last_updated_date;
        protected int _last_updated_by_user_id;
        protected string _last_updated_by_username;
        #endregion
        #region Constructors
        public Users() { }
        public Users(string first_name, string last_name, string username, string email, string phone, string password, unknown registration_date, string activation, DateTime last_login_date, int account_status, int user_type, string forgot_password, int password_reset, DateTime last_updated_date, int last_updated_by_user_id, string last_updated_by_username)
        {
            this._first_name=first_name;
            this._last_name=last_name;
            this._username=username;
            this._email=email;
            this._phone=phone;
            this._password=password;
            this._registration_date=registration_date;
            this._activation=activation;
            this._last_login_date=last_login_date;
            this._account_status=account_status;
            this._user_type=user_type;
            this._forgot_password=forgot_password;
            this._password_reset=password_reset;
            this._last_updated_date=last_updated_date;
            this._last_updated_by_user_id=last_updated_by_user_id;
            this._last_updated_by_username=last_updated_by_username;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string First_name
        {
            get {return _first_name;}
            set {_first_name=value;}
        }
        public virtual string Last_name
        {
            get {return _last_name;}
            set {_last_name=value;}
        }
        public virtual string Username
        {
            get {return _username;}
            set {_username=value;}
        }
        public virtual string Email
        {
            get {return _email;}
            set {_email=value;}
        }
        public virtual string Phone
        {
            get {return _phone;}
            set {_phone=value;}
        }
        public virtual string Password
        {
            get {return _password;}
            set {_password=value;}
        }
        public virtual unknown Registration_date
        {
            get {return _registration_date;}
            set {_registration_date=value;}
        }
        public virtual string Activation
        {
            get {return _activation;}
            set {_activation=value;}
        }
        public virtual DateTime Last_login_date
        {
            get {return _last_login_date;}
            set {_last_login_date=value;}
        }
        public virtual int Account_status
        {
            get {return _account_status;}
            set {_account_status=value;}
        }
        public virtual int User_type
        {
            get {return _user_type;}
            set {_user_type=value;}
        }
        public virtual string Forgot_password
        {
            get {return _forgot_password;}
            set {_forgot_password=value;}
        }
        public virtual int Password_reset
        {
            get {return _password_reset;}
            set {_password_reset=value;}
        }
        public virtual DateTime Last_updated_date
        {
            get {return _last_updated_date;}
            set {_last_updated_date=value;}
        }
        public virtual int Last_updated_by_user_id
        {
            get {return _last_updated_by_user_id;}
            set {_last_updated_by_user_id=value;}
        }
        public virtual string Last_updated_by_username
        {
            get {return _last_updated_by_username;}
            set {_last_updated_by_username=value;}
        }
        #endregion
    }
    #endregion
}using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Oms_database
{
    #region Vendors
    public class Vendors
    {
        #region Member Variables
        protected int _id;
        protected string _name;
        protected string _phone;
        protected string _address;
        protected string _website;
        protected string _contact_person;
        protected string _account_number;
        protected int _approved;
        protected DateTime _date_added;
        protected int _added_by_user_id;
        protected string _added_by_username;
        protected int _last_updated_by_user_id;
        protected string _last_updated_by_username;
        protected DateTime _last_updated_date;
        protected int _deleted;
        protected DateTime _deleted_date;
        protected int _deleted_by_user_id;
        protected string _deleted_by_username;
        #endregion
        #region Constructors
        public Vendors() { }
        public Vendors(string name, string phone, string address, string website, string contact_person, string account_number, int approved, DateTime date_added, int added_by_user_id, string added_by_username, int last_updated_by_user_id, string last_updated_by_username, DateTime last_updated_date, int deleted, DateTime deleted_date, int deleted_by_user_id, string deleted_by_username)
        {
            this._name=name;
            this._phone=phone;
            this._address=address;
            this._website=website;
            this._contact_person=contact_person;
            this._account_number=account_number;
            this._approved=approved;
            this._date_added=date_added;
            this._added_by_user_id=added_by_user_id;
            this._added_by_username=added_by_username;
            this._last_updated_by_user_id=last_updated_by_user_id;
            this._last_updated_by_username=last_updated_by_username;
            this._last_updated_date=last_updated_date;
            this._deleted=deleted;
            this._deleted_date=deleted_date;
            this._deleted_by_user_id=deleted_by_user_id;
            this._deleted_by_username=deleted_by_username;
        }
        #endregion
        #region Public Properties
        public virtual int Id
        {
            get {return _id;}
            set {_id=value;}
        }
        public virtual string Name
        {
            get {return _name;}
            set {_name=value;}
        }
        public virtual string Phone
        {
            get {return _phone;}
            set {_phone=value;}
        }
        public virtual string Address
        {
            get {return _address;}
            set {_address=value;}
        }
        public virtual string Website
        {
            get {return _website;}
            set {_website=value;}
        }
        public virtual string Contact_person
        {
            get {return _contact_person;}
            set {_contact_person=value;}
        }
        public virtual string Account_number
        {
            get {return _account_number;}
            set {_account_number=value;}
        }
        public virtual int Approved
        {
            get {return _approved;}
            set {_approved=value;}
        }
        public virtual DateTime Date_added
        {
            get {return _date_added;}
            set {_date_added=value;}
        }
        public virtual int Added_by_user_id
        {
            get {return _added_by_user_id;}
            set {_added_by_user_id=value;}
        }
        public virtual string Added_by_username
        {
            get {return _added_by_username;}
            set {_added_by_username=value;}
        }
        public virtual int Last_updated_by_user_id
        {
            get {return _last_updated_by_user_id;}
            set {_last_updated_by_user_id=value;}
        }
        public virtual string Last_updated_by_username
        {
            get {return _last_updated_by_username;}
            set {_last_updated_by_username=value;}
        }
        public virtual DateTime Last_updated_date
        {
            get {return _last_updated_date;}
            set {_last_updated_date=value;}
        }
        public virtual int Deleted
        {
            get {return _deleted;}
            set {_deleted=value;}
        }
        public virtual DateTime Deleted_date
        {
            get {return _deleted_date;}
            set {_deleted_date=value;}
        }
        public virtual int Deleted_by_user_id
        {
            get {return _deleted_by_user_id;}
            set {_deleted_by_user_id=value;}
        }
        public virtual string Deleted_by_username
        {
            get {return _deleted_by_username;}
            set {_deleted_by_username=value;}
        }
        #endregion
    }
    #endregion
}